# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Clear-CsOnlineTelephoneNumberOrder {
    [CmdletBinding(PositionalBinding=$false)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # OrderId of the Search Order
        ${OrderId}
    )

    process {

        $null = $PSBoundParameters.Add("Action", "Cancel")
        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Complete-CsOnlineTelephoneNumberOrder @PSBoundParameters -ErrorAction Stop

    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Complete-CsOnlineTelephoneNumberOrder {
    [CmdletBinding(PositionalBinding=$false)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # OrderId of the Search Order
        ${OrderId}
    )

    process {

        $null = $PSBoundParameters.Add("Action", "Complete")
        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Complete-CsOnlineTelephoneNumberOrder @PSBoundParameters -ErrorAction Stop

    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Export-CsAutoAttendantHolidaysModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the AA whose holiday schedules are to be exported..
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Use ResponseType 1 as binary output
        $PSBoundParameters.Add("ResponseType", 1)

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantHolidays @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $internalOutput.ExportHolidayResultSerializedHolidayRecord
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Export-CsOnlineAudioFile

function Export-CsOnlineAudioFile {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Identity parameter is the identifier for the audio file.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [System.String]
        # The ApplicationId parameter is the identifier for the application which will use this audio file. 
        ${ApplicationId}
    )

    process {
        # Default Application ID to TenantGlobal and make it to the correct case
        if ($ApplicationId -eq "" -or $ApplicationId -like "TenantGlobal")
        {
            $ApplicationId = "TenantGlobal"
        }
        elseif ($ApplicationId -like "OrgAutoAttendant")
        {
            $ApplicationId = "OrgAutoAttendant"
        }
        elseif ($ApplicationId -like "HuntGroup")
        {
            $ApplicationId = "HuntGroup"
        }

        $null = $PSBoundParameters.Remove("ApplicationId")
        $PSBoundParameters.Add("ApplicationId", $ApplicationId)

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $base64content = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Export-CsOnlineAudioFile @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($base64content -eq $null) {
            return $null
        }

        $output = [System.Convert]::FromBase64CharArray($base64content, 0, $base64content.Length)
        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Write diagnostic message back to console

function Find-CsGroupModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The SearchQuery parameter defines a search query to search the display name or the sip address or the GUID of groups.
        ${SearchQuery},

        [Parameter(Mandatory=$false, position=1)]
        [System.Nullable[System.UInt32]]
        # The MaxResults parameter identifies the maximum number of results to return.
        ${MaxResults},

        [Parameter(Mandatory=$false, position=2)]
        [System.Boolean]
        # The ExactMatchOnly parameter instructs the cmdlet to return exact matches only.
        ${ExactMatchOnly},

        [Parameter(Mandatory=$false, position=3)]
        [System.Boolean]
        # The MailEnabledOnly parameter instructs the cmdlet to return mail enabled only.
        ${MailEnabledOnly},

        [Parameter(Mandatory=$false, position=4)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Find-CsGroup @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = @()
        foreach($internalGroup in $internalOutput.Group)
        {
            $group = [Microsoft.Rtc.Management.Hosted.Group.Models.GroupModel]::new()
            $group.ParseFrom($internalGroup)
            $output += $group
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Put nested ApplicationInstance object as first layer object

function Find-CsOnlineApplicationInstanceModern {
    [OutputType([Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ApplicationInstance])]
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # A query for application instances by display name, telephone number, or GUID of the application instance
        ${SearchQuery},

        [Parameter(Mandatory=$false, position=1)]
        [System.Nullable[System.UInt32]]
        # The maximum number of results to return
        ${MaxResults},

        [Parameter(Mandatory=$false, position=2)]
        [Switch]
        # Instruct the cmdlet to return exact matches only
        ${ExactMatchOnly},

        [Parameter(Mandatory=$false, position=3)]
        [Switch]
        # Instruct the cmdlet to return only application instances that are associated to a configuration
        ${AssociatedOnly},

        [Parameter(Mandatory=$false, position=4)]
        [Switch]
        # instructs the cmdlet to return only application instances that are not associated to any configuration
        ${UnAssociatedOnly},

        [Parameter(Mandatory=$false, position=5)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Find-CsOnlineApplicationInstance @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = @()
        foreach($internalOutputApplicationInstance in $internalOutput.ApplicationInstance)
        {
            $applicationInstance = [Microsoft.Rtc.Management.Hosted.Online.Models.FindApplicationInstanceResult]::new()
            $applicationInstance.ParseFrom($internalOutputApplicationInstance)
            $output += $applicationInstance
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Get-CsAutoAttendantHolidaysModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the AA whose holiday schedules are to be exported..
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [System.String[]]
        # The identity for the AA to be retrieved.
        ${Years},

        [Parameter(Mandatory=$false, position=2)]
        [System.String[]]
        # If specified, the status records for each auto attendant in the result set are also retrieved.
        ${Names}
    )

    process {
        if ($PSBoundParameters.ContainsKey("Years")) {
            $null = $PSBoundParameters.Remove("Years")
            $PSBoundParameters.Add("Year", $Years)
        }

        if ($PSBoundParameters.ContainsKey("Names")) {
            $null = $PSBoundParameters.Remove("Names")
            $PSBoundParameters.Add("Name", $Names)
        }

        # Use ResponseType 0 as visualization record
        $PSBoundParameters.Add("ResponseType", 0)

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantHolidays @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = @()
        foreach($internalHolidayVisualizationRecord in $internalOutput.HolidayVisualizationRecord)
        {
            $holidayVisualizationRecord = [Microsoft.Rtc.Management.Hosted.OAA.Models.HolidayVisRecord]::new()
            $holidayVisualizationRecord.ParseFrom($internalHolidayVisualizationRecord)
            $output += $holidayVisualizationRecord
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of the cmdlet

function Get-CsAutoAttendantModern {
    [CmdletBinding(DefaultParameterSetName='GetAllParamSet', PositionalBinding=$false)]
    param(
        [Parameter(Mandatory=$true, position=0, ParameterSetName='GetSpecificParameterSet')]
        [System.String]
        # The identity for the AA to be retrieved.
        ${Identity},

        [Parameter(Mandatory=$false, position=1, ParameterSetName='GetAllParamSet')]
        [Switch]
        # If specified, the status records for each auto attendant in the result set are also retrieved.
        ${IncludeStatus},

        [Parameter(Mandatory=$false, position=2, ParameterSetName='GetAllParamSet')]
        [Int]
        # The First parameter indicates the maximum number of auto attendants to retrieve as the result.
        ${First},

        [Parameter(Mandatory=$false, position=3, ParameterSetName='GetAllParamSet')]
        [Int]
        # The Skip parameter indicates the number of initial auto attendants to skip in the result.
        ${Skip},

        [Parameter(Mandatory=$false, position=4, ParameterSetName='GetAllParamSet')]
        [Switch]
        # If specified, only auto attendants' names, identities and associated application instances will be retrieved.
        ${ExcludeContent},

        [Parameter(Mandatory=$false, position=5, ParameterSetName='GetAllParamSet')]
        [System.String]
        # If specified, only auto attendants whose names match that value would be returned.
        ${NameFilter},

        [Parameter(Mandatory=$false, position=6, ParameterSetName='GetAllParamSet')]
        [System.String]
        # If specified, the retrieved auto attendants would be sorted by the specified property.
        ${SortBy},

        [Parameter(Mandatory=$false, position=7, ParameterSetName='GetAllParamSet')]
        [Switch]
        # If specified, the retrieved auto attendants would be sorted in descending order.
        ${Descending},

        [Parameter(Mandatory=$false, position=8)]
        [Switch]
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("IncludeStatus")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        # Get common parameters
        $PSBoundCommonParameters = @{}
        foreach($p in $PSBoundParameters.GetEnumerator())
        {
            $PSBoundCommonParameters += @{$p.Key = $p.Value}
        }
        $null = $PSBoundCommonParameters.Remove("Identity")
        $null = $PSBoundCommonParameters.Remove("First")
        $null = $PSBoundCommonParameters.Remove("Skip")
        $null = $PSBoundCommonParameters.Remove("ExcludeContent")
        $null = $PSBoundCommonParameters.Remove("NameFilter")
        $null = $PSBoundCommonParameters.Remove("SortBy")
        $null = $PSBoundCommonParameters.Remove("Descending")

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendant @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = @()
        foreach($internalOutputAutoAttendant in $internalOutput.AutoAttendant)
        {
            $autoAttendant = [Microsoft.Rtc.Management.Hosted.OAA.Models.AutoAttendant]::new()
            $autoAttendant.ParseFrom($internalOutputAutoAttendant, $ExcludeContent)

            if ($Identity -or $IncludeStatus)
            {
                # Append common parameter here
                $getCsAutoAttendantStatusParameters = @{Identity = $autoAttendant.Identity}
                foreach($p in $PSBoundCommonParameters.GetEnumerator())
                {
                    $getCsAutoAttendantStatusParameters += @{$p.Key = $p.Value}
                }

                $internalStatus = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantStatus @getCsAutoAttendantStatusParameters

                $autoAttendant.AmendStatus($internalStatus)
            }

            $output += $autoAttendant
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of the cmdlet

function Get-CsAutoAttendantStatusModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the AA to be retrieved.
        ${Identity}

    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantStatus -Identity $Identity

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.StatusRecord]::new()
        $output.ParseFrom($internalOutput)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Get-CsAutoAttendantSupportedLanguageModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # The Identity parameter designates a specific language to be retrieved.
        ${Identity}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # Use ResponseType 1 as binary output
        if ($PSBoundParameters.ContainsKey('Identity')) {
            $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantSupportedLanguage @PSBoundParameters

            # Stop execution if internal cmdlet is failing
            if ($internalOutput -eq $null) {
                return $null
            }

            Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

            $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.Language]::new()
            $output.ParseFrom($internalOutput)

            $output
        } else {
            $tenantInfoOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantTenantInformation @PSBoundParameters

            # Stop execution if internal cmdlet is failing
            if ($tenantInfoOutput -eq $null) {
                return $null
            }

            Write-AdminServiceDiagnostic($tenantInfoOutput.Diagnostic)

            $supportedLanguagesOutput = @()
            foreach ($supportedLanguage in $tenantInfoOutput.TenantInformationSupportedLanguage) {
                $languageOutput = [Microsoft.Rtc.Management.Hosted.OAA.Models.Language]::new()
                $languageOutput.ParseFrom($supportedLanguage)
                $supportedLanguagesOutput += $languageOutput
            }

            $supportedLanguagesOutput
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Get-CsAutoAttendantSupportedTimeZoneModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # The Identity parameter specifies a time zone to be retrieved.
        ${Identity}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # Use ResponseType 1 as binary output
        if ($PSBoundParameters.ContainsKey('Identity')) {
            $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantSupportedTimeZone @PSBoundParameters

            # Stop execution if internal cmdlet is failing
            if ($internalOutput -eq $null) {
                return $null
            }

            Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

            $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.TimeZone]::new()
            $output.ParseFrom($internalOutput)

            $output
        } else {
            $tenantInfoOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantTenantInformation @PSBoundParameters

            # Stop execution if internal cmdlet is failing
            if ($tenantInfoOutput -eq $null) {
                return $null
            }

            Write-AdminServiceDiagnostic($tenantInfoOutput.Diagnostic)

            $supportedTimezonesOutput = @()
            foreach ($supportedTimezone in $tenantInfoOutput.TenantInformationSupportedTimeZone) {
                $timezoneOutput = [Microsoft.Rtc.Management.Hosted.OAA.Models.TimeZone]::new()
                $timezoneOutput.ParseFrom($supportedTimezone)
                $supportedTimezonesOutput += $timezoneOutput
            }

            $supportedTimezonesOutput
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Get-CsAutoAttendantTenantInformationModern {
    [CmdletBinding(PositionalBinding=$true)]
    param()

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantTenantInformation @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.TenantInformation]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the results to the custom objects

function Get-CsCallQueueModern {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]
        [System.String]
        # The identity of the call queue which is retrieved.
        ${Identity},

        [Parameter(Mandatory=$false)]
        [int]
        # The First parameter gets the first N Call Queues.
        ${First},

        [Parameter(Mandatory=$false)]
        [int]
        # The Skip parameter skips the first N Call Queues. It is intended to be used for pagination purposes.
        ${Skip},

        [Parameter(Mandatory=$false)]
        [switch]
        # The ExcludeContent parameter only displays the Name and Id of the Call Queues.
        ${ExcludeContent},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The Sort parameter specifies the property used to sort.
        ${Sort},

        [Parameter(Mandatory=$false)]
        [switch]
        # The Descending parameter is used to sort descending.
        ${Descending},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The NameFilter parameter returns Call Queues where name contains specified string
        ${NameFilter},

        [Parameter(Mandatory=$false)]
        [Switch]
        # Allow the cmdlet to run anyway
        ${Force}
    )

    process {
        if (${Identity} -and (${First} -or ${Skip} -or ${ExcludeContent} -or ${Sort} -or ${Descending} -or ${NameFilter})) {
            throw "Identity parameter cannot be used with any other parameter."
        }

        # Set the 'FilterInvalidObos' query parameter value to false.
        $PSBoundParameters.Add('FilterInvalidObos', $false)

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsCallQueue @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)

        if (${Identity} -ne '') {
            $callQueue = [Microsoft.Rtc.Management.Hosted.CallQueue.Models.CallQueue]::new()
            $callQueue.ParseFrom($result.CallQueue)
        } else {
            $callQueues = @()
            foreach ($model in $result.CallQueue) {
                $callQueue = [Microsoft.Rtc.Management.Hosted.CallQueue.Models.CallQueue]::new()
                if ($ExcludeContent) {
                    $callQueues += $callQueue.ParseFrom($model, $true)
                } else {
                    $callQueues += $callQueue.ParseFrom($model)
                }
            }
            $callQueues
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the results to the custom objects

function Get-CsConfigurationModern {
    [CmdletBinding(DefaultParameterSetName = 'ConfigType')]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='ConfigType')]
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [Parameter(Mandatory=$true, ParameterSetName='Filter')]
        [System.String]
        # Type of configuration retrieved.
        ${ConfigType},

        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        # Name of configuration retrieved.
        ${Identity},

        [Parameter(Mandatory=$true, ParameterSetName='Filter')]
        [System.String]
        # Name of configuration retrieved.
        ${Filter}
    )

    process {
        $xdsConfigurationOutput0 = $null
        
        $HashArguments = @{ ConfigType = $ConfigType}

        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            $HashArguments.Add('ConfigName', $Identity)
        }

        $xdsConfigurationOutput0 = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsConfiguration @HashArguments
		
        $xdsConfigurationOutput = ($xdsConfigurationOutput0 | %{
            Convert-PsCustomObjectToPsObject (ConvertFrom-Json -InputObject $_)
        })

        if (![string]::IsNullOrWhiteSpace($Filter))
        {
            $xdsConfigurationOutput = $xdsConfigurationOutput | Where-Object {($_.Identity -Like "$Filter") -or ($_.Identity -Like "Tag:$Filter")}
        }

        $xdsConfigurationOutput = Set-FormatOnConfigObject -ConfigObject $xdsConfigurationOutput -ConfigType $ConfigType

        if($ConfigType -eq 'TenantFederationSettings')
        {
            $xdsConfigurationOutput = Set-FixTenantFedConfigObject -ConfigObject $xdsConfigurationOutput
            $xdsConfigurationOutput = Convert-PsCustomObjectToPsObject ($xdsConfigurationOutput)
        }

        return (Sort-GlobalFirst $xdsConfigurationOutput)
    }
}

# output Identity=Global before other identities
function Sort-GlobalFirst($out)
{
    $out | ?{ $_.Identity -eq "Global" }
    $out | ?{ $_.Identity -ne "Global" }
}

# convert PSCustom Object to PSObject by using psserializer
function Custom-ToString($xnode)
{
    $props_to_hide = @("Element","XsAnyElements","XsAnyAttributes")

    $nodes = $xnode.SelectNodes('*[name() = "MS" or name() = "Props"]/*')
    $values = ($nodes | % {
        if ($_.N -notin $props_to_hide)
        {
            $val = $_.SelectSingleNode("text()").Value
            if ($_.Name -eq "B") { $val = [bool]::Parse($val)}
            "$($_.N)=$val"
        }
    })
    if ($values) { [string]::Join(";", $values) }
}

function Convert-PsCustomObjectToPsObject($in)
{
    $serialized = [System.Management.Automation.PSSerializer]::Serialize($in)
    $xml = [xml]$serialized
    foreach ($obj in $xml.GetElementsByTagName("Obj"))
    {
        if ($obj.Item("LST") -eq $null -and $obj.Item("Props") -eq $null)
        {
            $props = $xml.CreateElement("Props", $xml.Objs.xmlns)
            $null = $obj.PrependChild($props)

            if ($obj.Item("ToString") -eq $null)
            {
                $text = Custom-ToString $obj
                if ($text -ne $null)
                {
                    $tostring = $xml.CreateElement("ToString", $xml.Objs.xmlns)
                    $tostring.InnerText = $text
                    $null = $obj.PrependChild($tostring)
                }
            }
        }
    }
    return [System.Management.Automation.PSSerializer]::Deserialize($xml.OuterXml)
}

function Get-FormatsForConfig {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [string]
        # The int status from status record
        ${ConfigType}
    )
    process {
         
        $mappings = @(
            "ApplicationAccessPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Meeting.ApplicationAccessPolicy",
            "ApplicationMeetingConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.PlatformApplications.ApplicationMeetingConfiguration",
            "CallingLineIdentity=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.CallingLineIdentity",
            "DialPlan=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.LocationProfile",
            "ExternalAccessPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.ExternalAccess.ExternalAccessPolicy",
            "InboundExemptNumberPattern=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.InboundExemptNumberPattern#Decorated",
            "OnlineAudioConferencingRoutingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.OnlineAudioConferencingRoutingPolicy",
            "OnlineDialinConferencingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.OnlineDialinConferencing.OnlineDialinConferencingPolicy",
            "OnlineDialinConferencingTenantConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.OnlineDialInConferencing.OnlineDialinConferencingTenantConfiguration",
            "OnlineDialInConferencingTenantSettings=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.OnlineDialInConferencing.OnlineDialInConferencingTenantSettings",
            "OnlineDialInConferencingTenantSettings.AllowedDialOutExternalDomains=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.OnlineDialInConferencing.OnlineDialInConferencingAllowedDomain",
            "OnlineDialOutPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.OnlineDialOut.OnlineDialOutPolicy",
            "OnlinePSTNGateway=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.AzurePSTNTrunkConfiguration.TrunkConfig#Decorated2",
            "OnlinePstnUsages=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.OnlinePstnUsages",
            "OnlineVoicemailPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.OnlineVoicemail.OnlineVoicemailPolicy",
            "OnlineVoiceRoute=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.OnlineRoute#Decorated",
            "OnlineVoiceRoutingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.OnlineVoiceRoutingPolicy",
            "PrivacyConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.UserServices.PrivacyConfiguration",
            "TeamsAcsFederationConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.AcsConfiguration.TeamsAcsFederationConfiguration",
            "TeamsAppPermissionPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsAppPermissionPolicy",
            "TeamsAppPermissionPolicy.DefaultCatalogApps=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.DefaultCatalogApp",
            "TeamsAppPermissionPolicy.GlobalCatalogApps=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.GlobalCatalogApp",
            "TeamsAppPermissionPolicy.PrivateCatalogApps=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.PrivateCatalogApp",
            "TeamsAppSetupPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsAppSetupPolicy",
            "TeamsAppSetupPolicy.AppPresetList=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.AppPreset",
            "TeamsAppSetupPolicy.AppPresetMeetingList=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.AppPresetMeeting",
            "TeamsAppSetupPolicy.PinnedAppBarApps=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.PinnedApp",
            "TeamsAppSetupPolicy.PinnedMessageBarApps=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.PinnedMessageBarApp",
            "TeamsAudioConferencingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.TeamsAudioConferencing.TeamsAudioConferencingPolicy",
            "TeamsCallHoldPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsCallHoldPolicy",
            "TeamsCallingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsCallingPolicy",
            "TeamsCallParkPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsCallParkPolicy",
            "TeamsChannelsPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsChannelsPolicy",
            "TeamsClientConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsConfiguration.TeamsClientConfiguration",
            "TeamsComplianceRecordingApplication.ComplianceRecordingPairedApplications=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.ComplianceRecordingPairedApplication",
            "TeamsComplianceRecordingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsComplianceRecordingPolicy",
            "TeamsComplianceRecordingPolicy.ComplianceRecordingApplications=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.ComplianceRecordingApplication",
            "TeamsCortanaPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsCortanaPolicy",
            "TeamsEducationAssignmentsAppPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsEducationAssignmentsAppPolicy",
            "TeamsEmergencyCallingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsEmergencyCallingPolicy",
            "TeamsEmergencyCallRoutingPolicy.EmergencyNumbers=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsEmergencyNumber",
            "TeamsEmergencyCallRoutingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsEmergencyCallRoutingPolicy",
            "TeamsFeedbackPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsFeedbackPolicy",
            "TeamsGuestCallingConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsConfiguration.TeamsGuestCallingConfiguration",
            "TeamsGuestMeetingConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsConfiguration.TeamsGuestMeetingConfiguration",
            "TeamsGuestMessagingConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsConfiguration.TeamsGuestMessagingConfiguration",
            "TeamsIPPhonePolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsIPPhonePolicy",
            "TeamsMeetingBroadcastConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsConfiguration.TeamsMeetingBroadcastConfiguration",
            "TeamsMeetingBroadcastPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsMeetingBroadcastPolicy",
            "TeamsMeetingConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsMeetingConfiguration.TeamsMeetingConfiguration",
            "TeamsMeetingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Meeting.TeamsMeetingPolicy",
            "TeamsMessagingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsMessagingPolicy",
            "TeamsMigrationConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsMigrationConfiguration.TeamsMigrationConfiguration",
            "TeamsMobilityPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsMobilityPolicy",
            "TeamsNetworkRoamingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsNetworkRoamingPolicy",
            "TeamsNotificationAndFeedsPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsNotificationAndFeedsPolicy",
            "TeamsShiftsAppPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsShiftsAppPolicy",
            "TeamsShiftsPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsShiftsPolicy",
            "TeamsSurvivableBranchAppliance=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.SurvivableBranchAppliance#Decorated",
            "TeamsSurvivableBranchAppliancePolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.TeamsBranchSurvivabilityPolicy",
            "TeamsTargetingPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsTargetingPolicy",
            "TeamsUpdateManagementPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsUpdateManagementPolicy",
            "TeamsUpgradeConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TeamsConfiguration.TeamsUpgradeConfiguration",
            "TeamsUpgradePolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsUpgradePolicy",
            "TeamsVdiPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsVdiPolicy",
            "TeamsVideoInteropServicePolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsVideoInteropServicePolicy",
            "TeamsWorkLoadPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsWorkLoadPolicy",
            "TenantBlockedCallingNumbers=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.TenantBlockedCallingNumbers",
            "TenantBlockedCallingNumbers.InboundBlockedNumberPatterns=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.InboundBlockedNumberPattern",
            "TenantBlockedCallingNumbers.InboundExemptNumberPatterns=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.InboundExemptNumberPattern",
            "TenantDialPlan=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.TenantDialPlan",
            "TenantDialPlan.NormalizationRules=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Voice.NormalizationRule",
            "TenantFederationSettings=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.Edge.TenantFederationSettings",
            "TenantFederationSettings.AllowedDomains=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.Edge.AllowList",
            "TenantFederationSettings.BlockedDomains=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.Edge.DomainPattern",
            "TenantLicensingConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantConfiguration.TenantLicensingConfiguration",
            "TenantMigrationConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantMigration.TenantMigrationConfiguration",
            "TenantNetworkConfiguration=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.TenantNetworkConfigurationSettings",
            "TenantNetworkConfiguration.NetworkRegions=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.NetworkRegionType#Decorated",
            "TenantNetworkConfiguration.NetworkSites=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.DisplayNetworkSiteWithExpandParametersType#Decorated",
            "TenantNetworkConfiguration.Subnets=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.SubnetType#Decorated",
            "TenantNetworkRegion=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.DisplayNetworkRegionType#Decorated",
            "TenantNetworkSite=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.DisplayNetworkSiteWithExpandParametersType#Decorated",
            "TenantNetworkSubnet=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.SubnetType#Decorated",
            "TenantTrustedIPAddress=Deserialized.Microsoft.Rtc.Management.WritableConfig.Settings.TenantNetworkConfiguration.TrustedIP#Decorated",
            "TeamsFilesPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsFilesPolicy",
            "TeamsEnhancedEncryptionPolicy=Deserialized.Microsoft.Rtc.Management.WritableConfig.Policy.Teams.TeamsEnhancedEncryptionPolicy"
        )

        $mappings | where {$_.StartsWith("$ConfigType")}
    }
}

function Set-FormatOnConfigObject {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true)]
        # Object on which typenames need to be set
        ${ConfigObject},
        
        [Parameter(Mandatory=$true)]
        # Type of configuration
        ${ConfigType}
    )
    process {
        $mappings = Get-FormatsForConfig -ConfigType $ConfigType
        $parenttn = $mappings | where {$_.StartsWith("$ConfigType=")}
        $parenttn = $parenttn.Split("=")[1]
        $childtnmappings = $mappings | where {$_.StartsWith("$ConfigType.")}
        foreach ($inst in $ConfigObject)
        {
            $inst.PsObject.TypeNames.Insert(0,$parenttn)
            foreach($tn in $childtnmappings)
            {
                $childtn = $tn.Split("=")[1]
                $childPropName = $tn.Split("=")[0].Split(".")[1]
                foreach($instc in $inst.$childPropName)
                {
                    $instc.PsObject.TypeNames.Insert(0,$childtn)
                }
            }
        }

        return $ConfigObject
    }
}

function Set-FixToStringOnAllowedDomains($in, $val)
{
    $serialized = [System.Management.Automation.PSSerializer]::Serialize($in)
    $xml = [xml]$serialized
    foreach ($obj in $xml.GetElementsByTagName("Obj"))
    {
        if ($obj.Attributes["N"].'#text' -eq 'AllowedDomains')
        {            
            if ($obj.Item("ToString") -ne $null)
            {
                $obj.Item("ToString").'#text' = $val
            }
        }
    }
    return [System.Management.Automation.PSSerializer]::Deserialize($xml.OuterXml)
}

function Set-FixTenantFedConfigObject {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true)]
        # Object for Get-CsTenantFederationConfiguration
        ${ConfigObject}
    )
    process {
        if($ConfigObject.AllowedDomains.AllowedDomain -eq $null)
		{
			$ConfigObject.AllowedDomains = New-CsEdgeAllowAllKnownDomains -MsftInternalProcessingMode TryModern
		}
		elseif($ConfigObject.AllowedDomains.AllowedDomain.Count -eq 0)
		{
			$ConfigObject = Set-FixToStringOnAllowedDomains -val "" -in  $ConfigObject
		}
		elseif($ConfigObject.AllowedDomains.AllowedDomain.Count -gt 0)
		{
			$str = "Domain=" + [string]::join(",Domain=",$ConfigObject.AllowedDomains.AllowedDomain.Domain)
			$ConfigObject = Set-FixToStringOnAllowedDomains -val $str -in  $ConfigObject
		}

		return $ConfigObject
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

<#
.Synopsis
Get meeting migration transaction history for a user
.Description
Get meeting migration transaction history for a user
#>
function Get-CsMeetingMigrationTransactionHistory {
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # Identity.
        # Supports UPN and SIP
        ${Identity},

        [Parameter()]
        [System.String]
        # CorrelationId
        ${CorrelationId},

        [Parameter()]
        [System.DateTime]
        # start time filter - to get meeting migration transaction history after starttime
        ${StartTime},

        [Parameter()]
        [System.DateTime]
        # end time filter - to get meeting migration transaction history before endtime
        ${EndTime}
    )

    process {
        try {
            # Fetching only Meeting Migration transaction history
            # need to pipe to convert-ToJson | Convert-FromJson to support output in list format and sending down to further pipeline commands.
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsMeetingMigrationTransactionHistoryModern -userIdentity $Identity -StartTime $StartTime -EndTime $EndTime -CorrelationId $CorrelationId | Foreach-Object  { ( ConvertTo-Json $_) } | Foreach-Object {ConvertFrom-Json $_} 
        } 
        catch 
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

<#
.Synopsis
Get meeting migration status for a user or at tenant level
.Description
Get meeting migration status for a user or tenant level
#>
function Get-CsMmsStatus {
    param(
        [Parameter()]
        [System.String]
        # end time filter - to get meeting migration status before endtime
        ${EndTime},

        [Parameter()]
        [System.String]
        # Identity.
        # Supports UPN and SIP, domainName LogonName
        ${Identity},

        [Parameter()]
        [System.String]
        # Meeting migration type - SfbToSfb, SfbToTeams, TeamsToTeams, AllToTeams, ToSameType, Unknown
        ${MigrationType},

        [Parameter()]
        [System.String]
        # start time filter - to get meeting migration status after starttime
        ${StartTime},

        [Parameter()]
        [switch]
        # SummaryOnly - to get only meting migration status summary.
        ${SummaryOnly},

        [Parameter()]
        [System.String]
        # state of meeting Migration status - Pending, InProgress, Failed, Succeeded
        ${State}   
    )

    process {
        try {
            if($PSBoundParameters.ContainsKey('SummaryOnly')) 
            {
                # Fetching only Meeting Migration status summary
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsMeetingMigrationStatusSummaryModern -Identity $Identity -StartTime $StartTime -EndTime $EndTime -State $state -MigrationType $MigrationType | ConvertTo-Json
            }
            else 
            {
                # Need to display output in a list format and should be able to pipe output to other cmdlets for filtering.
                # with Format-List, not able to send the output for piping. So did this Convert-ToJson and Converting object from Json which displays output in list format and also able to refer with index value.
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsMeetingMigrationStatusModern -Identity $Identity -StartTime $StartTime -EndTime $EndTime -State $state -MigrationType $MigrationType |  Foreach-Object  { ( ConvertTo-Json $_) } | Foreach-Object {ConvertFrom-Json $_}
            }
        } 
        catch 
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------
# Objective of this custom file: Integrate Get-CsOnlineDialinConferencingUser with Get-CsOdcUser and Search-CsOdcUser
function Get-CsOdcUserList {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$false)]
        [System.Nullable[System.Int32]]
        # Number of users to be returned
        ${ResultSize}
    )
    process {
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOdcUser -Identity $Identity
        }
        else
        {
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsOdcUser -Top $ResultSize
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------
# Objective of this custom file: Integrate Get-CsOnlineDialinConferencingUser with Get-CsOdcUser
function Get-CsOdcUserPoint {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity}
    )
    process {
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOdcUser -Identity $Identity
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Get-CsOnlineApplicationInstanceAssociationModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the application instance whose association is to be retrieved.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineApplicationInstanceAssociation @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.Online.Models.ApplicationInstanceAssociation]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of the cmdlet

function Get-CsOnlineApplicationInstanceAssociationStatusModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the application instance whose association provisioning status is to be retrieved.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineApplicationInstanceAssociationStatus @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)
        
        $output = [Microsoft.Rtc.Management.Hosted.Online.Models.StatusRecord]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Get-CsOnlineAudioFile

function Get-CsOnlineAudioFile {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # The Identity parameter is the identifier for the audio file.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [System.String]
        # The ApplicationId parameter is the identifier for the application which will use this audio file. 
        ${ApplicationId}
    )

    process {
        # Default Application ID to TenantGlobal and make it to the correct case
        if ($ApplicationId -eq "" -or $ApplicationId -like "TenantGlobal")
        {
            $ApplicationId = "TenantGlobal"
        }
        elseif ($ApplicationId -like "OrgAutoAttendant")
        {
            $ApplicationId = "OrgAutoAttendant"
        }
        elseif ($ApplicationId -like "HuntGroup")
        {
            $ApplicationId = "HuntGroup"
        }

        $null = $PSBoundParameters.Remove("ApplicationId")
        $PSBoundParameters.Add("ApplicationId", $ApplicationId)

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($Identity -ne "") {
            $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineAudioFile @PSBoundParameters

            # Stop execution if internal cmdlet is failing
            if ($internalOutput -eq $null) {
                return $null
            }

            $output = [Microsoft.Rtc.Management.Hosted.Online.Models.AudioFile]::new()
            $output.ParseFrom($internalOutput)
        }
        else {
            $internalOutputs = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineAudioFile @PSBoundParameters

            # Stop execution if internal cmdlet is failing
            if ($internalOutputs -eq $null) {
                return $null
            }

            $output = New-Object Collections.Generic.List[Microsoft.Rtc.Management.Hosted.Online.Models.AudioFile]
            foreach($internalOutput in $internalOutputs) {
                $audioFile = [Microsoft.Rtc.Management.Hosted.Online.Models.AudioFile]::new()
                $audioFile.ParseFrom($internalOutput)
                $output.Add($audioFile)
            }
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format enum of the cmdlet output

class ProcessedGetOnlineEnhancedEmergencyServiceDisclaimerResponse {
    [string]$Country
    [string]$Version
    [string]$Content
    [string]$Response
    [string]$RespondedByObjectId
    [DateTime]$ResponseTimestamp
    [string]$CorrelationId
    [string]$Locale
}

function Get-CsOnlineEnhancedEmergencyServiceDisclaimerModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # CountryOrRegion of the Emergency Disclaimer
        ${CountryOrRegion},
        [Parameter(Mandatory=$false)]
        [System.String]
        # Version of the Emergency Disclaimer
        ${Version}
    )

    process {
        
        $edresponse = ''
        
        try
        {
            
            $input = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineEnhancedEmergencyServiceDisclaimer @PSBoundParameters -ErrorAction Stop

            if ($input -ne $null -and $input.Response -ne $null)
            {
                switch ($input.Response)
                {
                    0 {$edresponse = 'None'}
                    1 {$edresponse = 'Accepted'}
                    2 {$edresponse = 'NotAccepted'}
                }

                $result = [ProcessedGetOnlineEnhancedEmergencyServiceDisclaimerResponse]::new()
                $result.Content = $input.Content
                $result.CorrelationId = $input.CorrelationId
                $result.Country = $input.Country
                $result.Locale = $input.Locale
                $result.RespondedByObjectId = $input.RespondedByObjectId
                $result.Response = $edresponse
                $result.ResponseTimestamp = $input.ResponseTimestamp
                $result.Version = $input.Version

                return $result   
            }
        }
        catch
        {
            Write-Host $_
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the results to the custom objects

function Get-CsOnlineScheduleModern {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$false)]
        [System.String]
        # The identity of the schedule which is retrieved.
        ${Id},
        
        [Parameter(Mandatory=$false)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }
        
        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineSchedule @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)

        if (${Id} -ne '') {
            $schedule = [Microsoft.Rtc.Management.Hosted.Online.Models.Schedule]::new()
            $schedule.ParseFrom($result)
        } else {
            $schedules = @()
            foreach ($model in $result.Schedule) {
                $schedule = [Microsoft.Rtc.Management.Hosted.Online.Models.Schedule]::new()
                $schedules += $schedule.ParseFrom($model)
            }
            $schedules
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Get-CsOnlineVoicemailUserSettingsModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the user for the voice mail settings
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineVMUserSetting @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        $result
            
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Transfer $PolisyList from user's input from string[] to object[], enable inline input

function Get-CsTeamTemplateList {
    [OutputType([Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ITeamTemplateSummary], [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.IErrorObject])]
    [CmdletBinding(DefaultParameterSetName='DefaultLocaleOverride', PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false)]
        [System.String]
        # The language and country code of templates localization.
        ${PublicTemplateLocale}
    )

    process {
        if ([string]::IsNullOrWhiteSpace($PublicTemplateLocale)) {
            $null = $PSBoundParameters.Add("PublicTemplateLocale", "en-US")
        }

        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsTeamTemplateList @PSBoundParameters
    }
}
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Get-CsTenant with Get-CsTenantObou

function Get-CsTenantPoint {
    [CmdletBinding(PositionalBinding=$true)]
    param()

    process {
        $tenant = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsTenantObou
        $allProperties = $tenant | Select-Object -Property * -ExcludeProperty LastProvisionTimeStamps, LastPublishTimeStamps 
        $allProperties | Add-Member -NotePropertyName LastProvisionTimeStamps -NotePropertyValue $tenant.LastProvisionTimeStamps.AdditionalProperties -passThru | Add-Member -NotePropertyName LastPublishTimeStamps -NotePropertyValue $tenant.LastPublishTimeStamps.AdditionalProperties 

        Write-Output $allProperties
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Get-CsOnlineUser with Get-CsUser and Search-CsUser

function Get-CsUserList {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$false)]
        [System.Nullable[System.Int32]]
        # Number of users to be returned
        ${ResultSize},

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        #To not display user policies in output
        ${SkipUserPolicies}
    )

    process {
        $defaultPropertySet = "Extended"
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            $user = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet
            $allProperties = $user | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain, LastProvisionTimeStamps, LastPublishTimeStamps 
            $allProperties | Add-Member -NotePropertyName LastProvisionTimeStamps -NotePropertyValue $user.LastProvisionTimeStamps.AdditionalProperties -passThru | Add-Member -NotePropertyName LastPublishTimeStamps -NotePropertyValue $user.LastPublishTimeStamps.AdditionalProperties 

            Write-Output $allProperties
        }
        else
        {
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser -Top $ResultSize -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain
        }
    }
}
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Get-CsOnlineUser with Get-CsUser

function Get-CsUserPoint {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        #To not display user policies in output
        ${SkipUserPolicies}
    )

    process {
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            $user = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet "Extended"

            $allProperties = $user | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain, LastProvisionTimeStamps, LastPublishTimeStamps 
            $allProperties | Add-Member -NotePropertyName LastProvisionTimeStamps -NotePropertyValue $user.LastProvisionTimeStamps.AdditionalProperties -passThru | Add-Member -NotePropertyName LastPublishTimeStamps -NotePropertyValue $user.LastPublishTimeStamps.AdditionalProperties 

            Write-Output $allProperties
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Get-CsOnlineUser with Get-CsUser and Search-CsUser

function Get-CsUserSearch {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$false)]
        [System.String]
        # Filter to be applied to the list of users
        ${Filter},

        [Parameter(Mandatory=$false)]
        [System.Nullable[System.Int32]]
        # Number of users to be returned
        ${ResultSize},

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        #To skip user policies in output
        ${SkipUserPolicies}
    )

    process {
        $defaultPropertySet = "Extended"
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            $user = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet
            $allProperties = $user | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain, LastProvisionTimeStamps, LastPublishTimeStamps 
            $allProperties | Add-Member -NotePropertyName LastProvisionTimeStamps -NotePropertyValue $user.LastProvisionTimeStamps.AdditionalProperties -passThru | Add-Member -NotePropertyName LastPublishTimeStamps -NotePropertyValue $user.LastPublishTimeStamps.AdditionalProperties 

            Write-Output $allProperties
        }
        elseif ([string]::IsNullOrWhiteSpace($Filter))
        {
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser  -Top $ResultSize -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain
        }
        else 
        {
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser -PSFilter $Filter -Top $ResultSize -SkipUserPolicy:$SkipUserPolicies -DefaultPropertySet $defaultPropertySet | Select-Object -Property * -ExcludeProperty Location, Number, DataCenter, PSTNconnectivity, SipDomain
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Get-CsOnlineVoiceUser with Get-CsUser 

function Get-CsVoiceUserList {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [System.Management.Automation.SwitchParameter]
        #To fetch location field
        ${ExpandLocation},

        [Parameter(Mandatory=$false)]
        [System.Nullable[System.Int32]]
        # Number of users to be returned
        ${First},

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        # To only fetch users which have a number assigned to them
        ${NumberAssigned},

        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        # To only fetch users which don't have a number assigned to them
        ${NumberNotAssigned},

        [Parameter(Mandatory=$false)]
        [System.Nullable[System.Guid]]
        # LocationId of users to be returned
        ${LocationId},

        [Parameter(Mandatory=$false)]
        [System.Nullable[System.Guid]]
        # CivicAddressId of users to be returned
        ${CivicAddressId},

        [Parameter(Mandatory=$false)]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Models.PSTNConnectivity]
        # PSTNConnectivity of the users to be returned
        ${PSTNConnectivity},

        [Parameter(Mandatory=$false)]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Models.EnterpriseVoiceStatus]
        # EnterpriseVoiceStatus of the users to be returned
        ${EnterpriseVoiceStatus}
    )
    process 
    {
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            if($ExpandLocation)
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -Includedefaultproperty:$false -VoiceUserQuery:$true -Select "Objectid,EnterpriseVoiceEnabled,
                DisplayName,Location,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain" | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                Location,
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
            else
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -Includedefaultproperty:$false -VoiceUserQuery:$true -Select "Objectid,EnterpriseVoiceEnabled,
                DisplayName,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain" | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                @{Name = 'Location' ; Expression = {""}},
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
        }
        else
        {
            if($NumberAssigned -and $NumberNotAssigned)
            {
                Write-Error "You can only pass either NumberAssigned or NumberNotAssigned at a time."
                return
            }

            if (($LocationId -and !$CivicAddressId) -or ($CivicAddressId -and !$LocationId))
            {
                Write-Error "LocationId and CivicAddressId must be provided together."
                return
            }    

            $filters = @()   #array of individual filters
            $addNumberInSelectProperties = $false
            if ($LocationId -and $CivicAddressId)
            {
                $filters += "Number/LocationId eq '$LocationId' and Number/CivicAddressId eq '$CivicAddressId'"
                $addNumberInSelectProperties = $true
            }
                
            if ($PSTNConnectivity)
            {
                if ($PSTNConnectivity -eq 'OnPremises' -or $PSTNConnectivity -eq 'Online')
                {
                    $filters += "PSTNConnectivity eq '$PSTNConnectivity'"
                }
            }

            if ($EnterpriseVoiceStatus)
            {
                if ($EnterpriseVoiceStatus -eq 'Enabled')
                {
                    $filters += "EnterpriseVoiceEnabled eq true"
                }
                elseif ($EnterpriseVoiceStatus -eq 'Disabled')
                {
                    $filters += "EnterpriseVoiceEnabled eq false"
                }
            }

            if ($NumberAssigned)
            {
                $filters += "LineUri ne '$null'"
            }
            elseif ($NumberNotAssigned)
            {
                $filters += "LineUri eq '$null'"
            }

            $filterstring = $filters -join " and "
            $selectProperties = "Objectid,EnterpriseVoiceEnabled,DisplayName,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain"

            if ($addNumberInSelectProperties -eq $true)
            {
                $selectProperties += ",Number"
            }
            
            if($ExpandLocation)
            {
                $selectProperties += ",Location"
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser  -Includedefaultproperty:$false -VoiceUserQuery:$true -Select $selectProperties -Filter $filterstring -Top $First | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                Location,
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
            else
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser  -Includedefaultproperty:$false -VoiceUserQuery:$true -Select $selectProperties -Filter $filterstring -Top $First | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                @{Name = 'Location' ; Expression = {""}},
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Get-CsOnlineVoiceUser with Get-CsUser 

function Get-CsVoiceUserPoint {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [switch]
        #To fetch location field
        ${ExpandLocation}
    )
    process {
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            if($ExpandLocation)
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -Includedefaultproperty:$false -VoiceUserQuery:$true -Select "Objectid,EnterpriseVoiceEnabled,
                DisplayName,Location,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain" | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                Location,
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
            else
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -Includedefaultproperty:$false -VoiceUserQuery:$true -Select "Objectid,EnterpriseVoiceEnabled,
                DisplayName,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain" | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                @{Name = 'Location' ; Expression = {""}},
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Transfer $PolicyRankings from user's input from string[] to object[]

function Grant-CsGroupPolicyPackageAssignment {
    [OutputType([System.String])]
    [CmdletBinding(DefaultParameterSetName='RequiredPolicyList',
               PositionalBinding=$false,
               SupportsShouldProcess,
               ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        $GroupId,

        [Parameter(Mandatory=$true, position=1)]
        $PackageName,

        [Parameter(position=2)]
        [System.String[]]
        $PolicyRankings
    )

    process {
        try {
            $Delimiters = ",", ".", ":", ";", " ", "`t"
            [psobject[]]$InternalRankingList = @()
            foreach ($PolicyTypeAndRank in $PolicyRankings)
            {
                $PolicyTypeAndRankArray = $PolicyTypeAndRank -Split {$Delimiters -contains $_}, 2
                $PolicyTypeAndRankArray = $PolicyTypeAndRankArray.Trim()
                if ($PolicyTypeAndRankArray.Count -lt 2)
                {
                    throw "Invalid Policy Type and Rank pair: $PolicyTypeAndRank. Please use a proper delimeter"
                }
                $PolicyTypeAndRankObject = [psobject]@{
                    PolicyType = $PolicyTypeAndRankArray[0]
                    Rank = $PolicyTypeAndRankArray[1] -as [int]
                }
                $InternalRankingList += $PolicyTypeAndRankObject
            }
            $null = $PSBoundParameters.Remove("PolicyRankings")
            $null = $PSBoundParameters.Add("PolicyRankings", $InternalRankingList)
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Grant-CsGroupPolicyPackageAssignment @PSBoundParameters
        }
        catch
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Grant-CsUserOrTenantPolicy with Grant-CsUserPolicy and Grant-CsTenantPolicy

function Grant-CsUserOrTenantPolicy {
    [CmdletBinding(PositionalBinding=$true, DefaultParameterSetName="Identity", SupportsShouldProcess=$true, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$false, Position=0, ParameterSetName="Identity", ValueFromPipelineByPropertyName=$true, ValueFromPipeline=$true)]
        [ValidateNotNullOrEmpty()]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        # Type of the policy
        ${PolicyType},        

        [Parameter(Mandatory=$false, Position=2)]
        [System.String]
        # Name of the policy instance
        ${PolicyName},

        [Parameter(Mandatory=$false, ParameterSetName="GrantToTenant")]
        [Switch]
        # Use global indicating grant to tenant
        ${Global},

        [Parameter(Mandatory=$false)]
        ${AdditionalParameters}
    )

    process {
        if (-not $PSBoundParameters.ContainsKey("PolicyName"))
        {
            # this parameter should be Mandatory=$true, however the [AllowNull]/[AllowEmptyString] attributes don't get surfaced to the wrapper cmdlet that is generated
            throw [System.Management.Automation.ParameterBindingException]::new("Cannot process command because of one or more missing mandatory parameters: PolicyName.")
        }
        if ([string]::IsNullOrWhiteSpace($Identity))
        {
            if (-not $Global)
            {
                Write-Warning 'This policy change applies to *ALL* users in this tenant, except any that have an explicit policy assignment. To skip this warning in the future, specify "-Global" when granting a policy to your entire tenant.'
            }
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Grant-CsTenantPolicy -PolicyType $PolicyType -PolicyName $PolicyName -AdditionalParameters $AdditionalParameters
        }
        else
        {
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Grant-CsUserPolicy -Identity $Identity -PolicyType $PolicyType -PolicyName $PolicyName -AdditionalParameters $AdditionalParameters
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Import-CsAutoAttendantHolidaysModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the AA whose holiday schedules are to be imported.
        ${Identity},

        [Parameter(Mandatory=$true, position=1)]
        [System.Collections.Hashtable]
        ${PropertyBag},

        [Parameter(Mandatory=$false, position=2)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        if ($PropertyBag['Input'] -ne $null) {
            $base64input = [System.Convert]::ToBase64String($PropertyBag['Input'])
            $PSBoundParameters.Add("SerializedHolidayRecord", $base64input)
        }
        $null = $PSBoundParameters.Remove("PropertyBag")

        $PSBoundParameters.Add("TenantId", "")
        $PSBoundParameters.Add("Id", "")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Import-CsAutoAttendantHolidays @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = @()
        foreach($internalImportHolidayStatus in $internalOutput.ImportAutoAttendantHolidayResultImportHolidayStatusRecord)
        {
            $importHolidayStatus = [Microsoft.Rtc.Management.Hosted.OAA.Models.HolidayImportResult]::new()
            $importHolidayStatus.ParseFrom($internalImportHolidayStatus)
            $output += $importHolidayStatus
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Base64 encode the content for the audio file

function Import-CsOnlineAudioFileModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # The ApplicationId parameter is the identifier for the application which will use this audio file. 
        ${ApplicationId},

        [Parameter(Mandatory=$true, position=1)]
        [System.String]
        # The FileName parameter is the name of the audio file.
        ${FileName},

        [Parameter(Mandatory=$true, position=2)]
        [System.Byte[]]
        # The Content parameter represents the content of the audio file.
        ${Content}
    )

    process {
        $base64content = [System.Convert]::ToBase64String($Content)
        $null = $PSBoundParameters.Remove("Content")
        $PSBoundParameters.Add("Content", $base64content)

        # Default Application ID to TenantGlobal and make it to the correct case
        if ($ApplicationId -eq "" -or $ApplicationId -like "TenantGlobal")
        {
            $ApplicationId = "TenantGlobal"
        }
        elseif ($ApplicationId -like "OrgAutoAttendant")
        {
            $ApplicationId = "OrgAutoAttendant"
        }
        elseif ($ApplicationId -like "HuntGroup")
        {
            $ApplicationId = "HuntGroup"
        }
        $null = $PSBoundParameters.Remove("ApplicationId")
        $PSBoundParameters.Add("ApplicationId", $ApplicationId)

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Import-CsOnlineAudioFile @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        $output = [Microsoft.Rtc.Management.Hosted.Online.Models.AudioFile]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this file is to throw an error message that it is deprecated or there is equivalent cmdlets that do the work

function Invoke-CsDeprecatedError {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # Error action.
        ${DeprecatedErrorMessage},

        [Parameter(Mandatory=$false)]
        [System.Collections.Hashtable]
        $PropertyBag
    )

    process {
        Write-Error -Message $DeprecatedErrorMessage
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of cmdlet

function New-CsAutoAttendantCallableEntityModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Identity parameter represents the ID of the callable entity
        ${Identity},

        [Parameter(Mandatory=$true, position=1)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallableEntityType]
        # The Type parameter represents the type of the callable entity
        ${Type},

        [Parameter(Mandatory=$false, position=2)]
        [Switch]
        # Enables the email transcription of voicemail, this is only supported with shared voicemail callable entities.
        ${EnableTranscription},

        [Parameter(Mandatory=$false, position=3)]
        [Switch]
        # Suppresses the "Please leave a message after the tone" system prompt when transferring to shared voicemail.
        ${EnableSharedVoicemailSystemPromptSuppression},

        [Parameter(Mandatory=$false, position=4)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantCallableEntity @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.CallableEntity]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Put nested ApplicationInstance object as first layer object

function New-CsAutoAttendantCallFlowModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Name parameter represents a unique friendly name for the call flow.
        ${Name},

        [Parameter(Mandatory=$false, position=1)]
        [PSObject[]]
        # If present, the prompts specified by the Greetings parameter (either TTS or Audio) are played before the call flow's menu is rendered.
        ${Greetings},

        [Parameter(Mandatory=$true, position=2)]
        [PSObject]
        # The Menu parameter identifies the menu to render when the call flow is executed.
        ${Menu}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($Greetings -ne $null) {
            $null = $PSBoundParameters.Remove('Greetings')
            $inputGreetings = @()
            foreach ($greeting in $Greetings) {
                $inputGreetings += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($greeting)
            }
            $PSBoundParameters.Add('Greeting', $inputGreetings)
        }

        if ($Menu -ne $null) {
            $null = $PSBoundParameters.Remove('Menu')
            if ($Menu.DialByNameEnabled) {
                $PSBoundParameters.Add('MenuDialByNameEnabled', $true)
            }
            $PSBoundParameters.Add('MenuDirectorySearchMethod', $Menu.DirectorySearchMethod)
            $PSBoundParameters.Add('MenuName', $Menu.Name)
            $inputMenuOptions = @()
            foreach ($menuOption in $Menu.MenuOptions) {
                $inputMenuOptions += [Microsoft.Rtc.Management.Hosted.OAA.Models.MenuOption]::CreateAutoGeneratedFromObject($menuOption)
            }
            $PSBoundParameters.Add('MenuOption', $inputMenuOptions)
            $inputMenuPrompts = @()
            foreach ($menuPrompt in $Menu.Prompts) {
                $inputMenuPrompts += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($menuPrompt)
            }
            $PSBoundParameters.Add('MenuPrompt', $inputMenuPrompts)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantCallFlow @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.CallFlow]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print diagnostic message from service

function New-CsAutoAttendantCallHandlingAssociationModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallHandlingAssociationType]
        # The Type parameter represents the type of the call handling association.
        ${Type},

        [Parameter(Mandatory=$true, position=1)]
        [System.String]
        # The ScheduleId parameter represents the schedule to be associated with the call flow.
        ${ScheduleId},

        [Parameter(Mandatory=$true, position=2)]
        [System.String]
        # The CallFlowId parameter represents the call flow to be associated with the schedule.
        ${CallFlowId},

        [Parameter(Mandatory=$false, position=3)]
        [Switch]
        # The Disable parameter, if set, establishes that the call handling association is created as disabled.
        ${Disable}
    )

    process {
        if ($Disable -eq $true) {
            $null = $PSBoundParameters.Remove('Disable')
        } else {
            $PSBoundParameters.Add('Enable', $true)
        }

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantCallHandlingAssociation @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.CallHandlingAssociation]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print diagnostic message from server respond

function New-CsAutoAttendantDialScopeModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [Switch]
        # Indicates that a dial-scope based on groups (distribution lists, security groups) is to be created.
        ${GroupScope},

        [Parameter(Mandatory=$true, position=1)]
        [System.String[]]
        # Refers to the IDs of the groups that are to be included in the dial-scope.
        ${GroupIds},

        [Parameter(Mandatory=$false, position=2)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        if ($GroupScope -eq $true) {
            $null = $PSBoundParameters.Remove('GroupScope')
        }

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantDialScope @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.DialScope]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format input of the cmdlet

function New-CsAutoAttendantMenuModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Name parameter represents a friendly name for the menu.
        ${Name},

        [Parameter(Mandatory=$false, position=1)]
        [PSObject[]]
        # The Prompts parameter reflects the prompts to play when the menu is activated.
        ${Prompts},

        [Parameter(Mandatory=$false, position=2)]
        [PSObject[]]
        # The MenuOptions parameter is a list of menu options for this menu.
        ${MenuOptions},

        [Parameter(Mandatory=$false, position=3)]
        [Switch]
        # The EnableDialByName parameter lets users do a directory search by recipient name and get transferred to the party.
        ${EnableDialByName},

        [Parameter(Mandatory=$false, position=4)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.DirectorySearchMethod]
        # The DirectorySearchMethod parameter lets you define the type of Directory Search Method for the Auto Attendant menu.
        ${DirectorySearchMethod}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($Prompts -ne $null) {
            $null = $PSBoundParameters.Remove('Prompts')
            $inputPrompts = @()
            foreach ($prompt in $Prompts) {
                $inputPrompts += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($prompt)
            }
            $PSBoundParameters.Add('Prompt', $inputPrompts)
        }

        if ($MenuOptions -ne $null) {
            $null = $PSBoundParameters.Remove('MenuOptions')
            $inputMenuOptions = @()
            foreach ($menuOption in $MenuOptions) {
                $inputMenuOptions += [Microsoft.Rtc.Management.Hosted.OAA.Models.MenuOption]::CreateAutoGeneratedFromObject($menuOption)
            }
            $PSBoundParameters.Add('MenuOption', $inputMenuOptions)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantMenu @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.Menu]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format input of the cmdlet

function New-CsAutoAttendantMenuOptionModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.ActionType]
        # The Action parameter represents the action to be taken when the menu option is activated. 
        ${Action},

        [Parameter(Mandatory=$true, position=1)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.DtmfTone]
        # The DtmfResponse parameter indicates the key on the telephone keypad to be pressed to activate the menu option. 
        ${DtmfResponse},

        [Parameter(Mandatory=$false, position=2)]
        [System.String[]]
        # The VoiceResponses parameter represents the voice responses to select a menu option when Voice Responses are enabled for the auto attendant.
        ${VoiceResponses},

        [Parameter(Mandatory=$false, position=3)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallableEntity]
        # The CallTarget parameter represents the target for call transfer after the menu option is selected.
        ${CallTarget},

        [Parameter(Mandatory=$false, position=4)]
        [PSObject]
        # The Prompt parameter represents the announcement prompt.
        ${Prompt}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($CallTarget -ne $null) {
            $null = $PSBoundParameters.Remove('CallTarget')
            $PSBoundParameters.Add('CallTargetId', $CallTarget.Id)
            $PSBoundParameters.Add('CallTargetType', $CallTarget.Type)
            if ($CallTarget.EnableTranscription) {
                $PSBoundParameters.Add('CallTargetEnableTranscription', $True)
            }
            if ($CallTarget.EnableSharedVoicemailSystemPromptSuppression) {
                $PSBoundParameters.Add('CallTargetEnableSharedVoicemailSystemPromptSuppression', $True)
            }
        }

        if ($Prompt -ne $null) {
            $typeNames = $Prompt.PSObject.TypeNames
            if ($typeNames -NotContains "Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt" -and $typeNames -NotContains "Deserialized.Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt") {
                throw "PSObject must be type of Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt or Deserialized.Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt"
            }
            
            $null = $PSBoundParameters.Remove('Prompt')
            $PSBoundParameters.Add('PromptActiveType', $Prompt.ActiveType)
            $PSBoundParameters.Add('PromptTextToSpeechPrompt', $Prompt.TextToSpeechPrompt)
            if ($Prompt.AudioFilePrompt -ne $null -and $Prompt.AudioFilePrompt.Id -ne $null) {
                $PSBoundParameters.Add('AudioFilePromptId', $Prompt.AudioFilePrompt.Id)
                $PSBoundParameters.Add('AudioFilePromptFileName', $Prompt.AudioFilePrompt.FileName)
                $PSBoundParameters.Add('AudioFilePromptDownloadUri', $Prompt.AudioFilePrompt.DownloadUri)
            }
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantMenuOption @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.MenuOption]::new()
        $output.ParseFrom($internalOutput)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of cmdlet

function New-CsAutoAttendantModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Name parameter is a friendly name that is assigned to the AA.
        ${Name},

        [Parameter(Mandatory=$true, position=1)]
        [System.String]
        # The LanguageId parameter is the language that is used to read text-to-speech (TTS) prompts.
        ${LanguageId},

        [Parameter(Mandatory=$false, position=2)]
        [System.String]
        # The VoiceId parameter represents the voice that is used to read text-to-speech (TTS) prompts.
        ${VoiceId},

        [Parameter(Mandatory=$true, position=3)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallFlow]
        # The DefaultCallFlow parameter is the flow to be executed when no other call flow is in effect (for example, during business hours).
        ${DefaultCallFlow},

        [Parameter(Mandatory=$false, position=4)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallableEntity]
        # The Operator parameter represents the address or PSTN number of the operator.
        ${Operator},

        [Parameter(Mandatory=$false, position=5)]
        [Switch]
        # The EnableVoiceResponse parameter indicates whether voice response for AA is enabled.
        ${EnableVoiceResponse},

        [Parameter(Mandatory=$true, position=6)]
        [System.String]
        # The TimeZoneId parameter represents the AA time zone.
        ${TimeZoneId},

        [Parameter(Mandatory=$false, position=7)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallFlow[]]
        # The CallFlows parameter represents call flows, which are required if they are referenced in the CallHandlingAssociations parameter.
        ${CallFlows},

        [Parameter(Mandatory=$false, position=8)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.CallHandlingAssociation[]]
        # The CallHandlingAssociations parameter represents the call handling associations.
        ${CallHandlingAssociations},

        [Parameter(Mandatory=$false, position=9)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.DialScope]
        # Specifies the users to which call transfers are allowed through directory lookup feature.
        ${InclusionScope},

        [Parameter(Mandatory=$false, position=10)]
        [Microsoft.Rtc.Management.Hosted.OAA.Models.DialScope]
        # Specifies the users to which call transfers are not allowed through directory lookup feature.
        ${ExclusionScope},

        [Parameter(Mandatory=$false, position=11)]
        [System.Guid[]]
        # The list of users who can change the greetings of auto attendant.
        ${GreetingsSettingAuthorizedUsers}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # Get common parameters
        $PSBoundCommonParameters = @{}
        foreach($p in $PSBoundParameters.GetEnumerator())
        {
            $PSBoundCommonParameters += @{$p.Key = $p.Value}
        }
        $null = $PSBoundCommonParameters.Remove("Name")
        $null = $PSBoundCommonParameters.Remove("LanguageId")
        $null = $PSBoundCommonParameters.Remove("VoiceId")
        $null = $PSBoundCommonParameters.Remove("DefaultCallFlow")
        $null = $PSBoundCommonParameters.Remove("Operator")
        $null = $PSBoundCommonParameters.Remove("EnableVoiceResponse")
        $null = $PSBoundCommonParameters.Remove("TimeZoneId")
        $null = $PSBoundCommonParameters.Remove("CallFlows")
        $null = $PSBoundCommonParameters.Remove("CallHandlingAssociations")
        $null = $PSBoundCommonParameters.Remove("InclusionScope")
        $null = $PSBoundCommonParameters.Remove("ExclusionScope")
        $null = $PSBoundCommonParameters.Remove("GreetingsSettingAuthorizedUsers")

        if ($DefaultCallFlow -ne $null) {
            $null = $PSBoundParameters.Remove('DefaultCallFlow')
            if ($DefaultCallFlow.Id -ne $null) {
                $PSBoundParameters.Add('DefaultCallFlowId', $DefaultCallFlow.Id)
            }
            if ($DefaultCallFlow.Greetings -ne $null) {
                $defaultCallFlowGreetings = @()
                foreach ($defaultCallFlowGreeting in $DefaultCallFlow.Greetings) {
                    $defaultCallFlowGreetings += $defaultCallFlowGreeting.ParseToAutoGeneratedModel()
                }
                $PSBoundParameters.Add('DefaultCallFlowGreeting', $defaultCallFlowGreetings)
            }
            if ($DefaultCallFlow.Name -ne $null) {
                $PSBoundParameters.Add('DefaultCallFlowName', $DefaultCallFlow.Name)
            }
            if ($DefaultCallFlow.Menu -ne $null) {
                if ($DefaultCallFlow.Menu.DialByNameEnabled) {
                    $PSBoundParameters.Add('MenuDialByNameEnabled', $true)
                }
                $PSBoundParameters.Add('MenuDirectorySearchMethod', $DefaultCallFlow.Menu.DirectorySearchMethod.ToString())
                if ($DefaultCallFlow.Menu.Name -ne $null) {
                    $PSBoundParameters.Add('MenuName', $DefaultCallFlow.Menu.Name)
                }
                if ($DefaultCallFlow.Menu.MenuOptions -ne $null) {
                    $defaultCallFlowMenuOptions = @()
                    foreach ($defaultCallFlowMenuOption in $DefaultCallFlow.Menu.MenuOptions) {
                        $defaultCallFlowMenuOptions += $defaultCallFlowMenuOption.ParseToAutoGeneratedModel()
                    }
                    $PSBoundParameters.Add('MenuOption', $defaultCallFlowMenuOptions)
                }
                if ($DefaultCallFlow.Menu.Prompts -ne $null) {
                    $defaultCallFlowMenuPrompts = @()
                    foreach ($defaultCallFlowMenuPrompt in $DefaultCallFlow.Menu.Prompts) {
                        $defaultCallFlowMenuPrompts += $defaultCallFlowMenuPrompt.ParseToAutoGeneratedModel()
                    }
                    $PSBoundParameters.Add('MenuPrompt', $defaultCallFlowMenuPrompts)
                }
            }
        }
        if ($CallFlows -ne $null) {
            $null = $PSBoundParameters.Remove('CallFlows')
            $inputCallFlows = @()
            foreach ($callFlow in $CallFlows) {
                $inputCallFlows += $callFlow.ParseToAutoGeneratedModel()
            }
            $PSBoundParameters.Add('CallFlow', $inputCallFlows)
        }
        if ($CallHandlingAssociations -ne $null) {
            $null = $PSBoundParameters.Remove('CallHandlingAssociations')
            $inputCallHandlingAssociations = @()
            foreach ($callHandlingAssociation in $CallHandlingAssociations) {
                $inputCallHandlingAssociations += $callHandlingAssociation.ParseToAutoGeneratedModel()
            }
            $PSBoundParameters.Add('CallHandlingAssociation', $inputCallHandlingAssociations)
        }
        if ($Operator -ne $null) {
            $null = $PSBoundParameters.Remove('Operator')
            $PSBoundParameters.Add('OperatorEnableTranscription', $Operator.EnableTranscription)
            $PSBoundParameters.Add('OperatorId', $Operator.Id)
            $PSBoundParameters.Add('OperatorType', $Operator.Type.ToString())
        }
        if ($InclusionScope -ne $null) {
            $null = $PSBoundParameters.Remove('InclusionScope')
            $PSBoundParameters.Add('InclusionScopeType', $InclusionScope.Type.ToString())
            $PSBoundParameters.Add('InclusionScopeGroupDialScopeGroupId', $InclusionScope.GroupScope.GroupIds)
        }
        if ($ExclusionScope -ne $null) {
            $null = $PSBoundParameters.Remove('ExclusionScope')
            $PSBoundParameters.Add('ExclusionScopeType', $ExclusionScope.Type.ToString())
            $PSBoundParameters.Add('ExclusionScopeGroupDialScopeGroupId', $ExclusionScope.GroupScope.GroupIds)
        }
        if ($GreetingsSettingAuthorizedUsers -ne $null) {
            $null = $PSBoundParameters.Remove('GreetingsSettingAuthorizedUsers')
            $inputGreetingsSettingAuthorizedUsers = @()
            foreach ($greetingsSettingAuthorizedUser in $GreetingsSettingAuthorizedUsers) {
                $inputGreetingsSettingAuthorizedUsers += $greetingsSettingAuthorizedUser.ToString()
            }
            $PSBoundParameters.Add('GreetingsSettingAuthorizedUser', $inputGreetingsSettingAuthorizedUsers)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendant @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.AutoAttendant]::new()
        $output.ParseFrom($internalOutput.AutoAttendant)

        $getCsAutoAttendantStatusParameters = @{Identity = $output.Identity}
        foreach($p in $PSBoundCommonParameters.GetEnumerator())
        {
            $getCsAutoAttendantStatusParameters += @{$p.Key = $p.Value}
        }

        $internalStatus = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantStatus @getCsAutoAttendantStatusParameters
        $output.AmendStatus($internalStatus)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Base64 encode the content for the audio file

function New-CsAutoAttendantPromptModern {
    [CmdletBinding(PositionalBinding=$true, DefaultParameterSetName='TextToSpeechParameterSet')]
    param(
        [Parameter(Mandatory=$true, position=0, ParameterSetName="DualParameterSet")]
        [System.String]
        # The ActiveType parameter identifies the active type (modality) of the AA prompt. 
        ${ActiveType},

        [Parameter(Mandatory=$true, position=0, ParameterSetName="AudioFileParameterSet")]
        [Parameter(Mandatory=$false, position=1, ParameterSetName="DualParameterSet")]
        [Microsoft.Rtc.Management.Hosted.Online.Models.AudioFile]
        # The AudioFilePrompt parameter represents the audio to play when the prompt is activated (rendered).
        ${AudioFilePrompt},

        [Parameter(Mandatory=$true, position=0, ParameterSetName="TextToSpeechParameterSet")]
        [Parameter(Mandatory=$false, position=2, ParameterSetName="DualParameterSet")]
        [System.String]
        # The TextToSpeechPrompt parameter indicates the Text-to-Speech (TTS) prompt that is to be read when the prompt is activated.
        ${TextToSpeechPrompt}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($ActiveType -eq "") {
            $PSBoundParameters.Remove("ActiveType") | Out-Null
            if ($TextToSpeechPrompt -ne "") {
                $PSBoundParameters.Add("ActiveType", "TextToSpeech")
            } elseif ($AudioFilePrompt -ne $null) {
                $PSBoundParameters.Add("ActiveType", "AudioFile")
            } else {
                $PSBoundParameters.Add("ActiveType", "None")
            }
        }

        $ActiveType = "TextToSpeech"

        if ($AudioFilePrompt -ne $null) {
            $PSBoundParameters.Add('AudioFilePromptId', $AudioFilePrompt.Id)
            $PSBoundParameters.Add('AudioFilePromptFileName', $AudioFilePrompt.FileName)
            $PSBoundParameters.Add('AudioFilePromptDownloadUri', $AudioFilePrompt.DownloadUri)
            $PSBoundParameters.Remove('AudioFilePrompt') | Out-Null
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsAutoAttendantPrompt @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::new()
        $output.ParseFrom($internalOutput)

        return $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: parsing the return result to the CallQueue object type.

function New-CsCallQueueModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Name of the call queue to be created.
        ${Name},

        [Parameter(Mandatory=$false)]
        [System.Int16]
        # The AgentAlertTime parameter represents the time (in seconds) that a call can remain unanswered before it is automatically routed to the next agent.
        ${AgentAlertTime},

        [Parameter(Mandatory=$false)]
        [bool]
        # The AllowOptOut parameter indicates whether or not agents can opt in or opt out from taking calls from a Call Queue.
        ${AllowOptOut},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The DistributionLists parameter lets you add all the members of the distribution lists to the Call Queue. This is a list of distribution list GUIDs.
        ${DistributionLists},

        [Parameter(Mandatory=$false)]
        [bool]
        # The UseDefaultMusicOnHold parameter indicates that this Call Queue uses the default music on hold.
        ${UseDefaultMusicOnHold},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The WelcomeMusicAudioFileId parameter represents the audio file to play when callers are connected with the Call Queue.
        ${WelcomeMusicAudioFileId},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The MusicOnHoldAudioFileId parameter represents music to play when callers are placed on hold.
        ${MusicOnHoldAudioFileId},

        [Parameter(Mandatory=$false)]
        [Microsoft.Rtc.Management.Hosted.HuntGroup.Models.OverflowAction]
        # The OverflowAction parameter designates the action to take if the overflow threshold is reached.
        ${OverflowAction},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The OverflowActionTarget parameter represents the target of the overflow action.
        ${OverflowActionTarget},

        [Parameter(Mandatory=$false)]
        [System.Int16]
        # The OverflowThreshold parameter defines the number of calls that can be in the queue at any one time before the overflow action is triggered.
        ${OverflowThreshold},

        [Parameter(Mandatory=$false)]
        [Microsoft.Rtc.Management.Hosted.HuntGroup.Models.TimeoutAction]
        # The TimeoutAction parameter defines the action to take if the timeout threshold is reached.
        ${TimeoutAction},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The TimeoutActionTarget represents the target of the timeout action.
        ${TimeoutActionTarget},

        [Parameter(Mandatory=$false)]
        [System.Int16]
        # The TimeoutThreshold parameter defines the time (in seconds) that a call can be in the queue before that call times out.
        ${TimeoutThreshold},

        [Parameter(Mandatory=$false)]
        [Microsoft.Rtc.Management.Hosted.HuntGroup.Models.RoutingMethod]
        # The RoutingMethod defines how agents will be called in a Call Queue.
        ${RoutingMethod},

        [Parameter(Mandatory=$false)]
        [bool]
        # The PresenceBasedRouting parameter indicates whether or not presence based routing will be applied while call being routed to Call Queue agents.
        ${PresenceBasedRouting},

        [Parameter(Mandatory=$false)]
        [bool]
        # The ConferenceMode parameter indicates whether or not Conference mode will be applied on calls for current call queue.
        ${ConferenceMode},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The Users parameter lets you add agents to the Call Queue.
        ${Users},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The LanguageId parameter indicates the language that is used to play shared voicemail prompts.
        ${LanguageId},

        [Parameter(Mandatory=$false)]
        [System.String]
        # This parameter is reserved for Microsoft internal use only.
        ${LineUri},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The OboResourceAccountIds parameter lets you add resource account with phone number to the Call Queue.
        ${OboResourceAccountIds},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The OverflowSharedVoicemailTextToSpeechPrompt parameter indicates the Text-to-Speech (TTS) prompt which is to be played as a greeting to the caller when transferred to shared voicemail on overflow.
        ${OverflowSharedVoicemailTextToSpeechPrompt},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The OverflowSharedVoicemailAudioFilePrompt parameter indicates the unique identifier for the Audio file prompt which is to be played as a greeting to the caller when transferred to shared voicemail on overflow.
        ${OverflowSharedVoicemailAudioFilePrompt},

        [Parameter(Mandatory=$false)]
        [bool]
        # The EnableOverflowSharedVoicemailTranscription parameter is used to turn on transcription for voicemails left by a caller on overflow.
        ${EnableOverflowSharedVoicemailTranscription},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The TimeoutSharedVoicemailTextToSpeechPrompt parameter indicates the Text-to-Speech (TTS) prompt which is to be played as a greeting to the caller when transferred to shared voicemail on timeout.
        ${TimeoutSharedVoicemailTextToSpeechPrompt},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The TimeoutSharedVoicemailAudioFilePrompt parameter indicates the unique identifier for the Audio file prompt which is to be played as a greeting to the caller when transferred to shared voicemail on timeout.
        ${TimeoutSharedVoicemailAudioFilePrompt},

        [Parameter(Mandatory=$false)]
        [bool]
        # The EnableTimeoutSharedVoicemailTranscription parameter is used to turn on transcription for voicemails left by a caller on timeout.
        ${EnableTimeoutSharedVoicemailTranscription},

        [Parameter(Mandatory=$false)]
        [System.String]
        # Id of the channel to connect a call queue to.
        ${ChannelId},

        [Parameter(Mandatory=$false)]
        [System.Guid]
        # Guid should contain 32 digits with 4 dashes (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).
        ${ChannelUserObjectId}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey('LineUri')) {
            # Stick with the current TRPS cmdlet policy of silently ignoring the LineUri. Later, we need to remove this param from
            # TRPS and ConfigAPI based cmdlets. Public facing document must be updated as well.
            $PSBoundParameters.Remove('LineUri') | Out-Null
        }

        if ($PresenceBasedRouting -ne $null) {
            $PSBoundParameters.Add('PresenceAwareRouting', $PresenceBasedRouting)
            $PSBoundParameters.Remove('PresenceBasedRouting') | Out-Null
        }

        if ($ChannelId -ne '') {
            $PSBoundParameters.Add('ThreadId', $ChannelId)
            $PSBoundParameters.Remove('ChannelId') | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsCallQueue @PSBoundParameters
        
        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.CallQueue.Models.CallQueue]::new()
        $output.ParseFrom($result.CallQueue)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the results to the custom objects

function New-CsConfigurationModern {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # Type of configuration retrieved.
        ${ConfigType},

        [Parameter(Mandatory=$true)]
        [System.Collections.Hashtable]
        ${PropertyBag}
    )

    process {
        #Todo: validate that $PropertyBag contains Identity or just depend on the service to reject otherwise
        $xdsConfigurationOutput = $null

        Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsConfiguration -ConfigType $ConfigType -Body $PropertyBag -ErrorVariable err
        if ($err) { return }

        #Todo - Handle where new failed - because the identity already exists, rbac or someother server error
        #Todo: Ensure to test this under TPM, given we are referring the Microsoft.Teams.ConfigAPI.Cmdlets module
        $xdsConfigurationOutput = Get-CsConfigurationModern -ConfigType $ConfigType -Identity $PropertyBag['Identity']

        $xdsConfigurationOutput
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Transfer $PolisyList from user's input from string[] to object[], enable inline input

function New-CsCustomPolicyPackage {
    [OutputType([System.String])]
    [CmdletBinding(DefaultParameterSetName='RequiredPolicyList',
               PositionalBinding=$false,
               SupportsShouldProcess,
               ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        $Identity,

        [Parameter(Mandatory=$true, position=1)]
        [System.String[]]
        $PolicyList,

        [Parameter(position=2)]
        $Description
    )

    process {
        try {
            $Delimiters = ",", ".", ":", ";", " ", "`t"
            [psobject[]]$InternalPolicyList = @()
            foreach ($PolicyTypeAndName in $PolicyList)
            {
                $PolicyTypeAndNameArray = $PolicyTypeAndName -Split {$Delimiters -contains $_}, 2
                $PolicyTypeAndNameArray = $PolicyTypeAndNameArray.Trim()
                if ($PolicyTypeAndNameArray.Count -lt 2)
                {
                    throw "Invalid Policy Type and Name pair: $PolicyTypeAndName. Please use a proper delimeter"
                }
                $PolicyTypeAndNameObject = [psobject]@{
                    PolicyType = $PolicyTypeAndNameArray[0]
                    PolicyName = $PolicyTypeAndNameArray[1]
                }
                $InternalPolicyList += $PolicyTypeAndNameObject
            }
            $null = $PSBoundParameters.Remove("PolicyList")
            $null = $PSBoundParameters.Add("PolicyList", $InternalPolicyList)
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsCustomPolicyPackage @PSBoundParameters
        }
        catch
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of the cmdlet

function New-CsOnlineApplicationInstanceAssociationModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String[]]
        # The Identities parameter is the identities of application instances to be associated with the provided configuration ID.
        ${Identities},

        [Parameter(Mandatory=$true, position=1)]
        [System.String]
        # The ConfigurationId parameter is the identity of the configuration that would be associatied with the provided application instances.
        ${ConfigurationId},

        [Parameter(Mandatory=$true, position=2)]
        [System.String]
        # The ConfigurationType parameter denotes the type of the configuration that would be associated with the provided application instances.
        ${ConfigurationType},

        [Parameter(Mandatory=$false, position=3)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        $internalOutputs = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsOnlineApplicationInstanceAssociation @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutputs -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutputs.Diagnostic)
        
        $output = [Microsoft.Rtc.Management.Hosted.Online.Models.AssociationOperationOutput]::new()
        $output.ParseFrom($internalOutputs)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the return result to the custom object

function New-CsOnlineDateTimeRangeModern {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Start parameter represents the start bound of the date-time range.
        ${Start},

        [Parameter(Mandatory=$false, position=1)]
        [System.String]
        # The End parameter represents the end bound of the date-time range.
        ${End},

        [Parameter(Mandatory=$false, position=2)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsOnlineDateTimeRange @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)
        $output = [Microsoft.Rtc.Management.Hosted.Online.Models.DateTimeRange]::new()
        $output.ParseFrom($result)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: assign parameters' values and customize output

function New-CsOnlineScheduleModern {    
    [CmdletBinding(DefaultParameterSetName="UnresolvedParamSet", SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # The name of the schedule which is created.
        ${Name},

        [Parameter(Mandatory=$true, ParameterSetName = "FixedScheduleParamSet")]
        [switch]
        # The FixedSchedule parameter indicates that a fixed schedule is to be created.
        ${FixedSchedule},

        [Parameter(Mandatory=$false, ParameterSetName = "FixedScheduleParamSet")]
        # List of date-time ranges for a fixed schedule.
        ${DateTimeRanges},

        [Parameter(Mandatory=$true, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        [switch]
        # The WeeklyRecurrentSchedule parameter indicates that a weekly recurrent schedule is to be created.
        ${WeeklyRecurrentSchedule},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Monday.
        ${MondayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Tuesday.
        ${TuesdayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Wednesday.
        ${WednesdayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Thursday.
        ${ThursdayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Friday.
        ${FridayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Saturday.
        ${SaturdayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        # List of time ranges for Sunday.
        ${SundayHours},

        [Parameter(Mandatory=$false, ParameterSetName = "WeeklyRecurrentScheduleParamSet")]
        [switch]
        # The flag for Complement enabled or not
        ${Complement},

        [Parameter(Mandatory=$false)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }

        $dateTimeRangeStandardFormat = 'yyyy-MM-ddTHH:mm:ss';

        # Get common parameters
        $params = @{}
        foreach($p in $PSBoundParameters.GetEnumerator())
        {
            $params += @{$p.Key = $p.Value}
        }
        $null = $params.Remove("FixedSchedule")
        $null = $params.Remove("DateTimeRanges")
        $null = $params.Remove("WeeklyRecurrentSchedule")
        $null = $params.Remove("MondayHours")
        $null = $params.Remove("TuesdayHours")
        $null = $params.Remove("WednesdayHours")
        $null = $params.Remove("ThursdayHours")
        $null = $params.Remove("FridayHours")
        $null = $params.Remove("SaturdayHours")
        $null = $params.Remove("SundayHours")
        $null = $params.Remove("Complement")


        if ($PsCmdlet.ParameterSetName -eq "UnresolvedParamSet") {
            throw "A schedule type must be specified. Please use -WeeklyRecurrentSchedule or -FixedSchedule parameters to create the appropriate type of schedule."
        }

        if ($PsCmdlet.ParameterSetName -eq "FixedScheduleParamSet") {
            $fixedScheduleDateTimeRanges = @()
            foreach ($dateTimeRange in $DateTimeRanges) {
                $fixedScheduleDateTimeRanges += @{
                    Start = $dateTimeRange.Start.ToString($dateTimeRangeStandardFormat)
                    End = $dateTimeRange.End.ToString($dateTimeRangeStandardFormat)
                }
            }
            $params['FixedScheduleDateTimeRange'] = $fixedScheduleDateTimeRanges
        }

        if ($PsCmdlet.ParameterSetName -eq "WeeklyRecurrentScheduleParamSet") {
            if ($MondayHours -ne $null -and $MondayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleMondayHour'] = @()
                foreach ($mondayHour in $MondayHours){
                    $params['WeeklyRecurrentScheduleMondayHour'] += @{
                        Start = $mondayHour.Start
                        End = $mondayHour.End
                    }
                }
            }
            if ($TuesdayHours -ne $null -and $TuesdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleTuesdayHour'] = @()
                foreach ($tuesdayHour in $TuesdayHours){
                    $params['WeeklyRecurrentScheduleTuesdayHour'] += @{
                        Start = $tuesdayHour.Start
                        End = $tuesdayHour.End
                    }
                }
            }
            if ($WednesdayHours -ne $null -and $WednesdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleWednesdayHour'] = @()
                foreach ($wednesdayHour in $WednesdayHours){
                    $params['WeeklyRecurrentScheduleWednesdayHour'] += @{
                        Start = $wednesdayHour.Start
                        End = $wednesdayHour.End
                    }
                }    
            }
            if ($ThursdayHours -ne $null -and $ThursdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleThursdayHour'] = @()
                    foreach ($thursdayHour in $ThursdayHours){
                        $params['WeeklyRecurrentScheduleThursdayHour'] += @{
                            Start = $thursdayHour.Start
                            End = $thursdayHour.End
                    }
                }
            }
            if ($FridayHours -ne $null -and $FridayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleFridayHour'] = @()
                foreach ($fridayHour in $FridayHours){
                    $params['WeeklyRecurrentScheduleFridayHour'] += @{
                        Start = $fridayHour.Start
                        End = $fridayHour.End
                    }
                }
            }
            if ($SaturdayHours -ne $null -and $SaturdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleSaturdayHour'] = @()
                foreach ($saturdayHour in $SaturdayHours){
                    $params['WeeklyRecurrentScheduleSaturdayHour'] += @{
                        Start = $saturdayHour.Start
                        End = $saturdayHour.End
                    }
                }
            }
            if ($SundayHours -ne $null -and $SundayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleSundayHour'] = @()
                foreach ($sundayHour in $SundayHours){
                    $params['WeeklyRecurrentScheduleSundayHour'] += @{
                        Start = $sundayHour.Start
                        End = $sundayHour.End
                    }
                }
            }
            if ($Complement) { $params['WeeklyRecurrentScheduleIsComplemented'] = $true }
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsOnlineSchedule @params

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)

        $schedule = [Microsoft.Rtc.Management.Hosted.Online.Models.Schedule]::new()
        $schedule.ParseFrom($result)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the return result to the custom object

function New-CsOnlineTimeRangeModern {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Start parameter represents the start bound of the time range.
        ${Start},

        [Parameter(Mandatory=$true, position=1)]
        [System.String]
        # The End parameter represents the end bound of the time range.
        ${End},

        [Parameter(Mandatory=$false, position=2)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsOnlineTimeRange @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)
        $output = [Microsoft.Rtc.Management.Hosted.Online.Models.TimeRange]::new()
        $output.ParseFrom($result)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function New-CsUserCallingDelegate {
    [CmdletBinding(DefaultParameterSetName="Identity")]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Identity},
        
	    [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Delegate},
        
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.Boolean]
        ${MakeCalls},
        
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.Boolean]     
        ${ManageSettings},
        
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.Boolean]
        ${ReceiveCalls}
    )

    process {

           Microsoft.Teams.ConfigAPI.Cmdlets.internal\New-CsUserCallingDelegate @PSBoundParameters
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Register-CsOdcServiceNumber

function Register-CsOdcServiceNumber {
    [CmdletBinding(PositionalBinding=$false, DefaultParameterSetName="ById")]
    param(

    [string]
    [ValidateNotNullOrEmpty()]
    [Parameter(Mandatory=$true, ParameterSetName="ById", Position=0)]
    ${Identity},

    [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ConferencingServiceNumber]
    [ValidateNotNull()]
    [Parameter(Mandatory=$true, ValueFromPipeline=$true, ParameterSetName="ByInstance")]
    ${Instance},

    [string]
    [ValidateNotNull()]
    ${BridgeId},

    [string]
    [ValidateNotNullOrEmpty()]
    ${BridgeName},

    [Alias('DC')]
    ${DomainController},

    [switch]
    ${Force})

    process {
        
        if ($Identity -ne "")
        {
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Register-CsOdcServiceNumber @PSBoundParameters
        }
        elseif ($Instance -ne $null)
        {
            $Body = [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ConferencingServiceNumber]::new()
            $Body.Number = $Instance.Number
            $Body.PrimaryLanguage = $Instance.PrimaryLanguage
            $Body.SecondaryLanguages = $Instance.SecondaryLanguages

            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Register-CsOdcServiceNumber -Body $Body -BridgeId $BridgeId -BridgeName $BridgeName
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Display the diagnostic if any

function Remove-CsAutoAttendantModern {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the AA to be removed.
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsAutoAttendant @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: print out the diagnostics

function Remove-CsCallQueueModern {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identifier of the call queue to be removed.
        ${Identity}, 

        [Parameter(Mandatory=$false)]
        [Switch]
        # Allow the cmdlet to run anyway
        ${Force}
    )

    process {
        # Default ErrorAction to Stop
        if (!$PSBoundParameters.ContainsKey('ErrorAction')) {
            $PSBoundParameters.Add('ErrorAction', 'Stop')
        }

        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        # Get the CallQueue to be deleted by Identity.
        $getParams = @{Identity = $Identity; FilterInvalidObos = $false}
        $getResult = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsCallQueue @getParams -ErrorAction Stop

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsCallQueue @PSBoundParameters
        Write-AdminServiceDiagnostic($result.Diagnostics)

        # Convert the fecthed CallQueue DTO to domain model and print.
        $deletedCallQueue= [Microsoft.Rtc.Management.Hosted.CallQueue.Models.CallQueue]::new()
        $deletedCallQueue.ParseFrom($getResult.CallQueue)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the identity

function Remove-CsConfigurationModern {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # Type of configuration deleted.
        ${ConfigType},

		[Parameter(Mandatory=$true)]
        [System.String]
        # Name of configuration deleted.
        ${Identity}
    )

    process {
        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsConfiguration -ConfigType $ConfigType -ConfigName $Identity
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of the cmdlet

function Remove-CsOnlineApplicationInstanceAssociationModern {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String[]]
        # The Identity parameter is the identity of application instances to be associated with the provided configuration ID.
        ${Identities},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # We want to flight our cmdlet if Force param is passed, but AutoRest doesn't support Force param.
        # Force param doesn't seem to do anything, so remove it if it's passed.
        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        # Get the array of Identities, and remove parameter 'Identities',
        # since api internal\Remove-CsOnlineApplicationInstanceAssociation takes only param 'Identity' as a string,
        # so need send a request for each identity (endpointId) by looping through all Identities.
        $endpointIdArr = @()

        if ($PSBoundParameters.ContainsKey('Identities')) {
            $endpointIdArr = $PSBoundParameters['Identities']
            $PSBoundParameters.Remove('Identities') | Out-Null
        }

        # Sends request for each identity (endpointId)
        foreach ($endpointId in $endpointIdArr) {
            $PSBoundParameters.Add('Identity', $endpointId)

            $internalOutputs = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsOnlineApplicationInstanceAssociation @PSBoundParameters
            $PSBoundParameters.Remove('Identity') | Out-Null

            # Stop execution if internal cmdlet is failing
            if ($internalOutputs -eq $null) {
                return $null
            }

            Write-AdminServiceDiagnostic($internalOutputs.Diagnostic)

            $output = [Microsoft.Rtc.Management.Hosted.Online.Models.AssociationOperationOutput]::new()
            $output.ParseFrom($internalOutputs)

            $output
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Add default App ID for Remove-CsOnlineAudioFile

function Remove-CsOnlineAudioFile {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The Identity parameter is the identifier for the audio file.
        ${Identity}
    )

    process {
        $null = $PSBoundParameters.Remove("ApplicationId")
        $PSBoundParameters.Add("ApplicationId", "TenantGlobal")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsOnlineAudioFile @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        $internalOutput
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: print out the diagnostic

function Remove-CsOnlineScheduleModern {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identifier of the schedule to be removed.
        ${Id},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsOnlineSchedule @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)
        $result
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Remove-CsOnlineTelephoneNumberModern {
    [CmdletBinding(PositionalBinding=$false)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String[]]
        # Telephone numbers to remove
        ${TelephoneNumber}
    )

    process {

        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsOnlineTelephoneNumberPrivate -TelephoneNumber $TelephoneNumber

    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Remove-CsPhoneNumberAssignment {
    [CmdletBinding(DefaultParameterSetName="RemoveSome")]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='RemoveSome')]
        [Parameter(Mandatory=$true, ParameterSetName='RemoveAll')]
        [System.String]
        ${Identity},

        [Parameter(Mandatory=$true, ParameterSetName='RemoveSome')]
        [System.String]
        ${PhoneNumber},
        
        [Parameter(Mandatory=$true, ParameterSetName='RemoveSome')]
        [System.String]
        ${PhoneNumberType},
        
        [Parameter(Mandatory=$true, ParameterSetName='RemoveAll')]
        [Switch]
        ${RemoveAll}
    )

    process {
        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsPhoneNumberAssignment @PSBoundParameters
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Remove-CsUserCallingDelegate {
    [CmdletBinding(DefaultParameterSetName="Identity")]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Identity},
        
	    [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Delegate}
    )

    process {

           Microsoft.Teams.ConfigAPI.Cmdlets.internal\Remove-CsUserCallingDelegate @PSBoundParameters
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of cmdlet

function Set-CsAutoAttendantModern {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [PSObject]
        # The Instance parameter is the object reference to the AA to be modified.
        ${Instance},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        # The Force parameter indicates if we force the action to be performed. (Deprecated)
        ${Force}
    )

    process {
        $null = $PSBoundParameters.Remove("Force")

        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        # Get common parameters
        $PSBoundCommonParameters = @{}
        foreach($p in $PSBoundParameters.GetEnumerator())
        {
            $PSBoundCommonParameters += @{$p.Key = $p.Value}
        }
        $null = $PSBoundCommonParameters.Remove("Instance")
        $null = $PSBoundCommonParameters.Remove("WhatIf")
        $null = $PSBoundCommonParameters.Remove("Confirm")

        $null = $PSBoundParameters.Remove('Instance')
        if ($Instance.Identity -ne $null) {
            $PSBoundParameters.Add('Identity', $Instance.Identity)
        }
        if ($Instance.Id -ne $null) {
            $PSBoundParameters.Add('Id', $Instance.Id)
        }
        if ($Instance.Name -ne $null) {
            $PSBoundParameters.Add('Name', $Instance.Name)
        }
        if ($Instance.LanguageId -ne $null) {
            $PSBoundParameters.Add('LanguageId', $Instance.LanguageId)
        }
        if ($Instance.TimeZoneId -ne $null) {
            $PSBoundParameters.Add('TimeZoneId', $Instance.TimeZoneId)
        }
        if ($Instance.TenantId -ne $null) {
            $PSBoundParameters.Add('TenantId', $Instance.TenantId.ToString())
        }
        if ($Instance.VoiceId -ne $null) {
            $PSBoundParameters.Add('VoiceId', $Instance.VoiceId)
        }
        if ($Instance.DialByNameResourceId -ne $null) {
            $PSBoundParameters.Add('DialByNameResourceId', $Instance.DialByNameResourceId)
        }
        if ($Instance.ApplicationInstances -ne $null) {
            $PSBoundParameters.Add('ApplicationInstance', $Instance.ApplicationInstances)
        }
        if ($Instance.VoiceResponseEnabled -eq $true) {
            $PSBoundParameters.Add('VoiceResponseEnabled', $true)
        }
        if ($Instance.DefaultCallFlow -ne $null) {
            $PSBoundParameters.Add('DefaultCallFlowId', $Instance.DefaultCallFlow.Id)
            $PSBoundParameters.Add('DefaultCallFlowName', $Instance.DefaultCallFlow.Name)
            $defaultCallFlowGreetings = @()
            if ($Instance.DefaultCallFlow.Greetings -ne $null) {
                foreach ($defaultCallFlowGreeting in $Instance.DefaultCallFlow.Greetings) {
                    $defaultCallFlowGreetings += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($defaultCallFlowGreeting)
                }
                $PSBoundParameters.Add('DefaultCallFlowGreeting', $defaultCallFlowGreetings)
            }
            if ($Instance.DefaultCallFlow.Menu -ne $null) {
                $PSBoundParameters.Add('MenuDialByNameEnabled', $Instance.DefaultCallFlow.Menu.DialByNameEnabled)
                $PSBoundParameters.Add('MenuDirectorySearchMethod', $Instance.DefaultCallFlow.Menu.DirectorySearchMethod.ToString())
                $PSBoundParameters.Add('MenuName', $Instance.DefaultCallFlow.Menu.Name)
                if ($Instance.DefaultCallFlow.Menu.MenuOptions -ne $null) {
                    $defaultCallFlowMenuOptions = @()
                    foreach($defaultCallFlowMenuOption in $Instance.DefaultCallFlow.Menu.MenuOptions) {
                        $defaultCallFlowMenuOptions += [Microsoft.Rtc.Management.Hosted.OAA.Models.MenuOption]::CreateAutoGeneratedFromObject($defaultCallFlowMenuOption)
                    }
                    $PSBoundParameters.Add('MenuOption', $defaultCallFlowMenuOptions)
                }
                if ($Instance.DefaultCallFlow.Menu.Prompts -ne $null) {
                    $defaultCallFlowMenuPrompts = @()
                    foreach($defaultCallFlowMenuPrompt in $Instance.DefaultCallFlow.Menu.Prompts) {
                        $defaultCallFlowMenuPrompts += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($defaultCallFlowMenuPrompt)
                    }
                    $PSBoundParameters.Add('MenuPrompt', $defaultCallFlowMenuPrompts)
                }
            }
        }
        if ($Instance.DirectoryLookupScope -ne $null) {
            if ($Instance.DirectoryLookupScope.InclusionScope -ne $null) {
                $PSBoundParameters.Add('InclusionScopeType', $Instance.DirectoryLookupScope.InclusionScope.Type.ToString())
                if ($Instance.DirectoryLookupScope.InclusionScope.GroupScope -ne $null) {
                    $PSBoundParameters.Add('InclusionScopeGroupDialScopeGroupId', $Instance.DirectoryLookupScope.InclusionScope.GroupScope.GroupIds)
                }
            } else {
                $PSBoundParameters.Add('InclusionScopeType', "Default")
            }
            if ($Instance.DirectoryLookupScope.ExclusionScope -ne $null) {
                $PSBoundParameters.Add('ExclusionScopeType', $Instance.DirectoryLookupScope.ExclusionScope.Type.ToString())
                if ($Instance.DirectoryLookupScope.ExclusionScope.GroupScope -ne $null) {
                    $PSBoundParameters.Add('ExclusionScopeGroupDialScopeGroupId', $Instance.DirectoryLookupScope.ExclusionScope.GroupScope.GroupIds)
                }
            } else {
                $PSBoundParameters.Add('ExclusionScopeType', "Default")
            }
        }
        if ($Instance.Operator -ne $null) {
            if ($Instance.Operator.EnableTranscription -eq $true) {
                $PSBoundParameters.Add('OperatorEnableTranscription', $true)
            }
            $PSBoundParameters.Add('OperatorId', $Instance.Operator.Id)
            $PSBoundParameters.Add('OperatorType', $Instance.Operator.Type.ToString())
        }
        if ($Instance.CallFlows -ne $null) {
            $callFlows = @()
            foreach ($callFlow in $Instance.CallFlows) {
                $generatedCallFlow = [Microsoft.Rtc.Management.Hosted.OAA.Models.CallFlow]::CreateAutoGeneratedFromObject($callFlow)

                if ($callFlow.Greetings -ne $null) {
                    $inputGreetings = @()
                    foreach ($greeting in $callFlow.Greetings) {
                        $inputGreetings += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($greeting)
                    }
                    $generatedCallFlow.Greeting = $inputGreetings
                }
                if ($callFlow.Menu.MenuOptions -ne $null) {
                    $menuOptions = @()
                    foreach ($menuOption in $callFlow.Menu.MenuOptions) {
                        $menuOptions += [Microsoft.Rtc.Management.Hosted.OAA.Models.MenuOption]::CreateAutoGeneratedFromObject($menuOption)
                    }
                    $generatedCallFlow.MenuOption = $menuOptions
                }
                if ($callFlow.Menu.Prompts -ne $null) {
                    $menuPrompts = @()
                    foreach ($menuPrompt in $callFlow.Menu.Prompts) {
                        $menuPrompts += [Microsoft.Rtc.Management.Hosted.OAA.Models.Prompt]::CreateAutoGeneratedFromObject($menuPrompt)
                    }
                    $generatedCallFlow.MenuPrompt = $menuPrompts
                }

                $callFlows += $generatedCallFlow
            }
            $PSBoundParameters.Add('CallFlow', $callFlows)
        }
        if ($Instance.CallHandlingAssociations -ne $null) {
            $callHandlingAssociations = @()
            foreach($callHandlingAssociation in $Instance.CallHandlingAssociations) {
                $callHandlingAssociations += [Microsoft.Rtc.Management.Hosted.OAA.Models.CallHandlingAssociation]::CreateAutoGeneratedFromObject($callHandlingAssociation)
            }
            $PSBoundParameters.Add('CallHandlingAssociation', $callHandlingAssociations)
        }
        if ($Instance.GreetingsSettingAuthorizedUsers -ne $null) {
            $greetingsSettingAuthorizedUsers = @()
            foreach($greetingsSettingAuthorizedUser in $Instance.GreetingsSettingAuthorizedUsers) {
                $greetingsSettingAuthorizedUsers += $greetingsSettingAuthorizedUser.ToString()
            }
            $PSBoundParameters.Add('GreetingsSettingAuthorizedUser', $greetingsSettingAuthorizedUsers)
        }
        if ($Instance.Schedules -ne $null) {
            $schedules = @()
            foreach($schedule in $Instance.Schedules) {
                $schedules += [Microsoft.Rtc.Management.Hosted.Online.Models.Schedule]::CreateAutoGeneratedFromObject($schedule)
            }
            $PSBoundParameters.Add('Schedule', $schedules)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsAutoAttendant @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)

        $output = [Microsoft.Rtc.Management.Hosted.OAA.Models.AutoAttendant]::new()
        $output.ParseFrom($internalOutput.AutoAttendant)

        $getCsAutoAttendantStatusParameters = @{Identity = $output.Identity}
        foreach($p in $PSBoundCommonParameters.GetEnumerator())
        {
            $getCsAutoAttendantStatusParameters += @{$p.Key = $p.Value}
        }

        $internalStatus = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsAutoAttendantStatus @getCsAutoAttendantStatusParameters
        $output.AmendStatus($internalStatus)

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: replacing the parameters' names.

function Set-CsCallQueueModern {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity of the call queue to be updated.
        ${Identity},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The Name of the call queue to be updated.
        ${Name},

        [Parameter(Mandatory=$false)]
        [System.Int16]
        # The AgentAlertTime parameter represents the time (in seconds) that a call can remain unanswered before it is automatically routed to the next agent.
        ${AgentAlertTime},

        [Parameter(Mandatory=$false)]
        [bool]
        # The AllowOptOut parameter indicates whether or not agents can opt in or opt out from taking calls from a Call Queue.
        ${AllowOptOut},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The DistributionLists parameter lets you add all the members of the distribution lists to the Call Queue. This is a list of distribution list GUIDs.
        ${DistributionLists},

        [Parameter(Mandatory=$false)]
        [bool]
        # The UseDefaultMusicOnHold parameter indicates that this Call Queue uses the default music on hold.
        ${UseDefaultMusicOnHold},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The WelcomeMusicAudioFileId parameter represents the audio file to play when callers are connected with the Call Queue.
        ${WelcomeMusicAudioFileId},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The MusicOnHoldAudioFileId parameter represents music to play when callers are placed on hold.
        ${MusicOnHoldAudioFileId},

        [Parameter(Mandatory=$false)]
        [Microsoft.Rtc.Management.Hosted.HuntGroup.Models.OverflowAction]
        # The OverflowAction parameter designates the action to take if the overflow threshold is reached.
        ${OverflowAction},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The OverflowActionTarget parameter represents the target of the overflow action.
        ${OverflowActionTarget},

        [Parameter(Mandatory=$false)]
        [System.Int16]
        # The OverflowThreshold parameter defines the number of calls that can be in the queue at any one time before the overflow action is triggered.
        ${OverflowThreshold},

        [Parameter(Mandatory=$false)]
        [Microsoft.Rtc.Management.Hosted.HuntGroup.Models.TimeoutAction]
        # The TimeoutAction parameter defines the action to take if the timeout threshold is reached.
        ${TimeoutAction},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The TimeoutActionTarget represents the target of the timeout action.
        ${TimeoutActionTarget},

        [Parameter(Mandatory=$false)]
        [System.Int16]
        # The TimeoutThreshold parameter defines the time (in seconds) that a call can be in the queue before that call times out.
        ${TimeoutThreshold},

        [Parameter(Mandatory=$false)]
        [Microsoft.Rtc.Management.Hosted.HuntGroup.Models.RoutingMethod]
        # The RoutingMethod defines how agents will be called in a Call Queue.
        ${RoutingMethod},

        [Parameter(Mandatory=$false)]
        [bool]
        # The PresenceBasedRouting parameter indicates whether or not presence based routing will be applied while call being routed to Call Queue agents.
        ${PresenceBasedRouting},

        [Parameter(Mandatory=$false)]
        [bool]
        # The ConferenceMode parameter indicates whether or not Conference mode will be applied on calls for current call queue.
        ${ConferenceMode},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The Users parameter lets you add agents to the Call Queue.
        ${Users},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The LanguageId parameter indicates the language that is used to play shared voicemail prompts.
        ${LanguageId},

        [Parameter(Mandatory=$false)]
        [System.String]
        # This parameter is reserved for Microsoft internal use only.
        ${LineUri},

        [Parameter(Mandatory=$false)]
        [System.Guid[]]
        # The OboResourceAccountIds parameter lets you add resource account with phone number to the Call Queue.
        ${OboResourceAccountIds},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The OverflowSharedVoicemailTextToSpeechPrompt parameter indicates the Text-to-Speech (TTS) prompt which is to be played as a greeting to the caller when transferred to shared voicemail on overflow.
        ${OverflowSharedVoicemailTextToSpeechPrompt},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The OverflowSharedVoicemailAudioFilePrompt parameter indicates the unique identifier for the Audio file prompt which is to be played as a greeting to the caller when transferred to shared voicemail on overflow.
        ${OverflowSharedVoicemailAudioFilePrompt},

        [Parameter(Mandatory=$false)]
        [bool]
        # The EnableOverflowSharedVoicemailTranscription parameter is used to turn on transcription for voicemails left by a caller on overflow.
        ${EnableOverflowSharedVoicemailTranscription},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The TimeoutSharedVoicemailTextToSpeechPrompt parameter indicates the Text-to-Speech (TTS) prompt which is to be played as a greeting to the caller when transferred to shared voicemail on timeout.
        ${TimeoutSharedVoicemailTextToSpeechPrompt},

        [Parameter(Mandatory=$false)]
        [System.String]
        # The TimeoutSharedVoicemailAudioFilePrompt parameter indicates the unique identifier for the Audio file prompt which is to be played as a greeting to the caller when transferred to shared voicemail on timeout.
        ${TimeoutSharedVoicemailAudioFilePrompt},

        [Parameter(Mandatory=$false)]
        [bool]
        # The EnableTimeoutSharedVoicemailTranscription parameter is used to turn on transcription for voicemails left by a caller on timeout.
        ${EnableTimeoutSharedVoicemailTranscription},

        [Parameter(Mandatory=$false)]
        [System.String]
        # Id of the channel to connect a call queue to.
        ${ChannelId},

        [Parameter(Mandatory=$false)]
        [System.Guid]
        # Guid should contain 32 digits with 4 dashes (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).
        ${ChannelUserObjectId},

        [Parameter(Mandatory=$false)]
        [Switch]
        # Allow the cmdlet to run anyway
        ${Force}
    )

    process {
        # Default ErrorAction to Stop
        if (!$PSBoundParameters.ContainsKey('ErrorAction')) {
            $PSBoundParameters.Add('ErrorAction', 'Stop')
        }

        if ($PSBoundParameters.ContainsKey('Force')) {
            $PSBoundParameters.Remove('Force') | Out-Null
        }

        # Get the existing CallQueue by Identity.
        $getParams = @{Identity = $Identity; FilterInvalidObos = $false}
        $getResult = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsCallQueue @getParams -ErrorAction Stop

        # Convert the existing CallQueue DTO to domain model.
        $existingCallQueue= [Microsoft.Rtc.Management.Hosted.CallQueue.Models.CallQueue]::new()
        $existingCallQueue.ParseFrom($getResult.CallQueue) | Out-Null

        # Take the delta from the existing CallQueue and apply it to the param hasthable to form
        # an appropriate DTO model for the CallQueue PUT API. FYI, CallQueue PUT API is very much
        # different from its AA counterpart which accepts params/properties to be updated only.
        
        # Param hashtable modification begins.
        if ($PSBoundParameters.ContainsKey('LineUri')) {
            # Stick with the current TRPS cmdlet policy of silently ignoring the LineUri. Later, we
            # need to remove this param from TRPS and ConfigAPI based cmdlets. Public facing document
            # must be updated as well.
            $PSBoundParameters.Remove('LineUri') | Out-Null
        }

        if ([string]::IsNullOrWhiteSpace($Name)) {
            $PSBoundParameters.Add('Name', $existingCallQueue.Name)
        }

        if (!$PSBoundParameters.ContainsKey('AgentAlertTime')) {
            $PSBoundParameters.Add('AgentAlertTime', $existingCallQueue.AgentAlertTime)
        }

        if ([string]::IsNullOrWhiteSpace($LanguageId) -and ![string]::IsNullOrWhiteSpace($existingCallQueue.LanguageId)) {
            $PSBoundParameters.Add('LanguageId', $existingCallQueue.LanguageId)
        }

        if (!$PSBoundParameters.ContainsKey('OverflowThreshold')) {
            $PSBoundParameters.Add('OverflowThreshold', $existingCallQueue.OverflowThreshold)
        }

        if (!$PSBoundParameters.ContainsKey('TimeoutThreshold')) {
            $PSBoundParameters.Add('TimeoutThreshold', $existingCallQueue.TimeoutThreshold)
        }

        if (!$PSBoundParameters.ContainsKey('RoutingMethod')) {
            $PSBoundParameters.Add('RoutingMethod', $existingCallQueue.RoutingMethod)
        }

        if (!$PSBoundParameters.ContainsKey('AllowOptOut') ) {
            $PSBoundParameters.Add('AllowOptOut', $existingCallQueue.AllowOptOut)
        }

        if (!$PSBoundParameters.ContainsKey('ConferenceMode')) {
            $PSBoundParameters.Add('ConferenceMode', $existingCallQueue.ConferenceMode)
        }

        if (!$PSBoundParameters.ContainsKey('PresenceBasedRouting')) {
            $PSBoundParameters.Add('PresenceAwareRouting', $existingCallQueue.PresenceBasedRouting)
        }
        else {
            $PSBoundParameters.Add('PresenceAwareRouting', $PresenceBasedRouting)
            $PSBoundParameters.Remove('PresenceBasedRouting') | Out-Null
        }

        if ([string]::IsNullOrWhiteSpace($ChannelId)) {
            if (![string]::IsNullOrWhiteSpace($existingCallQueue.ChannelId)) {
                $PSBoundParameters.Add('ThreadId', $existingCallQueue.ChannelId)
            }
        }
        else {
            $PSBoundParameters.Add('ThreadId', $ChannelId)
            $PSBoundParameters.Remove('ChannelId') | Out-Null
        }

        if ($null -eq $OboResourceAccountIds -or $OboResourceAccountIds.Length -eq 0) {
            if ($null -ne $existingCallQueue.OboResourceAccountIds -and $existingCallQueue.OboResourceAccountIds.Length -gt 0) {
                $PSBoundParameters.Add('OboResourceAccountIds', $existingCallQueue.OboResourceAccountIds)
            }
        }

        if (!$PSBoundParameters.ContainsKey('WelcomeMusicAudioFileId') -and ![string]::IsNullOrWhiteSpace($existingCallQueue.WelcomeMusicResourceId)) {
            $PSBoundParameters.Add('WelcomeMusicAudioFileId', $existingCallQueue.WelcomeMusicResourceId)
        }

        if (!$PSBoundParameters.ContainsKey('MusicOnHoldAudioFileId') -and !$PSBoundParameters.ContainsKey('UseDefaultMusicOnHold')) {
            # The already persiting values cannot be conflicting as those were validated by admin service.
            if (![string]::IsNullOrWhiteSpace($existingCallQueue.MusicOnHoldResourceId)) {
                $PSBoundParameters.Add('MusicOnHoldAudioFileId', $existingCallQueue.MusicOnHoldResourceId)
            }
            if ($null -ne $existingCallQueue.UseDefaultMusicOnHold) {
                $PSBoundParameters.Add('UseDefaultMusicOnHold', $existingCallQueue.UseDefaultMusicOnHold)
            }
        }
        elseif ($UseDefaultMusicOnHold -eq $false -and !$PSBoundParameters.ContainsKey('MusicOnHoldAudioFileId')) {
            if (![string]::IsNullOrWhiteSpace($existingCallQueue.MusicOnHoldResourceId)) {
                $PSBoundParameters.Add('MusicOnHoldAudioFileId', $existingCallQueue.MusicOnHoldResourceId)
            }
        }

        if ($null -eq $DistributionLists -or $DistributionLists.Length -eq 0) {
            if ($null -ne $existingCallQueue.DistributionLists -and $existingCallQueue.DistributionLists.Length -gt 0) {
                $PSBoundParameters.Add('DistributionLists', $existingCallQueue.DistributionLists)
            }
        }

        if ($null -eq $Users -or $Users.Length -eq 0) {
            if ($null -ne $existingCallQueue.Users -and $existingCallQueue.Users.Length -gt 0) {
                $PSBoundParameters.Add('Users', $existingCallQueue.Users)
            }
        }

        if ([string]::IsNullOrWhiteSpace($OverflowSharedVoicemailTextToSpeechPrompt) -and ![string]::IsNullOrWhiteSpace($existingCallQueue.OverflowSharedVoicemailTextToSpeechPrompt)) {
            $PSBoundParameters.Add('OverflowSharedVoicemailTextToSpeechPrompt', $existingCallQueue.OverflowSharedVoicemailTextToSpeechPrompt)
        }

        if ([string]::IsNullOrWhiteSpace($OverflowSharedVoicemailAudioFilePrompt) -and ![string]::IsNullOrWhiteSpace($existingCallQueue.OverflowSharedVoicemailAudioFilePrompt)) {
            $PSBoundParameters.Add('OverflowSharedVoicemailAudioFilePrompt', $existingCallQueue.OverflowSharedVoicemailAudioFilePrompt)
        }

        if (!$PSBoundParameters.ContainsKey('EnableOverflowSharedVoicemailTranscription')) {
        if ($existingCallQueue.EnableOverflowSharedVoicemailTranscription -ne $null) {
                $PSBoundParameters.Add('EnableOverflowSharedVoicemailTranscription', $existingCallQueue.EnableOverflowSharedVoicemailTranscription)
            }
        }

        if ([string]::IsNullOrWhiteSpace($OverflowActionTarget) -and ![string]::IsNullOrWhiteSpace($existingCallQueue.OverflowActionTargetId)) {
            $PSBoundParameters.Add('OverflowActionTarget', $existingCallQueue.OverflowActionTargetId)
        }

        if (!$PSBoundParameters.ContainsKey('OverflowAction')) {
            $PSBoundParameters.Add('OverflowAction', $existingCallQueue.OverflowAction)
        }

        if ([string]::IsNullOrWhiteSpace($TimeoutSharedVoicemailTextToSpeechPrompt) -and ![string]::IsNullOrWhiteSpace($existingCallQueue.TimeoutSharedVoicemailTextToSpeechPrompt) ) {
            $PSBoundParameters.Add('TimeoutSharedVoicemailTextToSpeechPrompt', $existingCallQueue.TimeoutSharedVoicemailTextToSpeechPrompt)
        }

        if ([string]::IsNullOrWhiteSpace($TimeoutSharedVoicemailAudioFilePrompt) -and ![string]::IsNullOrWhiteSpace($existingCallQueue.TimeoutSharedVoicemailAudioFilePrompt)) {
            $PSBoundParameters.Add('TimeoutSharedVoicemailAudioFilePrompt', $existingCallQueue.TimeoutSharedVoicemailAudioFilePrompt)
        }

        if (!$PSBoundParameters.ContainsKey('EnableTimeoutSharedVoicemailTranscription')) {
            if ($existingCallQueue.EnableTimeoutSharedVoicemailTranscription -ne $null) {
                $PSBoundParameters.Add('EnableTimeoutSharedVoicemailTranscription', $existingCallQueue.EnableTimeoutSharedVoicemailTranscription)
            }
        }

        if ([string]::IsNullOrWhiteSpace($TimeoutActionTarget) -and ![string]::IsNullOrWhiteSpace($existingCallQueue.TimeoutActionTargetId)) {
            $PSBoundParameters.Add('TimeoutActionTarget', $existingCallQueue.TimeoutActionTargetId)
        }

        if (!$PSBoundParameters.ContainsKey('TimeoutAction')) {
            $PSBoundParameters.Add('TimeoutAction', $existingCallQueue.TimeoutAction)
        }

        # End of param hashtable modification

        # Update the CallQueue.
        $updateResult = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsCallQueue @PSBoundParameters
        Write-AdminServiceDiagnostic($updateResult.Diagnostic)

        # Unfortunately, CallQueue PUT API does not return a CallQueue DTO model. We need to GET the CallQueue again
        # to print the updated model.
        $getResult = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsCallQueue @getParams
        
        $updatedCallQueue = [Microsoft.Rtc.Management.Hosted.CallQueue.Models.CallQueue]::new()
        $updatedCallQueue.ParseFrom($getResult.CallQueue)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: transforming the results to the custom objects

function Set-CsConfigurationModern {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [System.String]
        # Type of configuration retrieved.
        ${ConfigType},

        [Parameter(Mandatory=$true)]
        [System.Collections.Hashtable]
        ${PropertyBag}
    )

    process {
        
        if(!($PropertyBag.ContainsKey('Identity')))
        {
            $PropertyBag['Identity'] =  "Global"
        }

        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsConfiguration -ConfigType $ConfigType -ConfigName $PropertyBag['Identity'] -Body $PropertyBag
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Set-CsOdcBridgeModern

function Set-CsOdcBridgeModern {
    [CmdletBinding(PositionalBinding=$false)]
    param(
    [string]
    ${Name},

    [string]
    ${DefaultServiceNumber},

    [switch]
    ${SetDefault},

    [string]
    ${Identity},

    [Alias('DC')]
    ${DomainController},

    [switch]
    ${Force},

    [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.IConferencingBridge]
    [Parameter(ValueFromPipeline)]
    ${Instance},

    [switch]
    ${AsJob})

    process {
        if ($Identity -ne "") {
            # This should map to SetCsOdcBridge_SetExpanded.cs
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcBridge @PSBoundParameters
        }
        elseif ($Name -ne "") {
            $Body = [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.BridgeUpdateRequest]::new()

            if ($PSBoundParameters.ContainsKey("DefaultServiceNumber") -and $PSBoundParameters["DefaultServiceNumber"] -ne "") {
                $Body.DefaultServiceNumber = $DefaultServiceNumber
            }

            $Body.SetDefault = $SetDefault

            # This should map to SetCsOdcBridge_Set1.cs
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcBridge -Name $Name -Body $Body
        }
        elseif ($Instance -ne $null) {
           if ($DefaultServiceNumber -eq "" -and !($Instance.DefaultServiceNumber -eq $null)) {
                $DefaultServiceNumber = $Instance.DefaultServiceNumber.Number
           }

           if ($PSBoundParameters.ContainsKey('SetDefault') -eq $false) {
               $SetDefault = $Instance.IsDefault
           }

           $Body = [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.BridgeUpdateRequest]::new()

           if ($DefaultServiceNumber -ne "") {
            $Body.DefaultServiceNumber = $DefaultServiceNumber
           }

           $Body.SetDefault = $SetDefault
           $Body.Name = $Instance.Name

           # This should map to SetCsOdcBridge_Set.cs
           $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcBridge -Identity $Instance.Identity -Body $Body
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Set-CsOdcServiceNumber

function Set-CsOdcServiceNumber {
    [CmdletBinding(PositionalBinding=$false)]
    param(
    [string]
    ${Identity},

    [string]
    ${PrimaryLanguage},

    [string[]]
    ${SecondaryLanguages},

    [switch]
    ${RestoreDefaultLanguages},

    [Alias('DC')]
    ${DomainController},

    [switch]
    ${Force},

    [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ConferencingServiceNumber]
    [Parameter(ValueFromPipeline)]
    ${Instance})

    process {
        if ($Identity -ne ""){
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcServiceNumber @PSBoundParameters
        }
        elseif ($Instance -ne $null) {
            $Body = [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ServiceNumberUpdateRequest]::new()

            if ($PrimaryLanguage -ne "" ){
                $Body.PrimaryLanguage = $PrimaryLanguage
            }
            else {
                $Body.PrimaryLanguage = $Instance.PrimaryLanguage
            }

            if ($SecondaryLanguages -ne "") {
                $Body.SecondaryLanguage = $SecondaryLanguages
            }
            else {
                $Body.SecondaryLanguage = $Instance.SecondaryLanguages
            }

            if ($RestoreDefaultLanguages -eq $true) {
                $Body.RestoreDefaultLanguage = $RestoreDefaultLanguages
            }

            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcServiceNumber -Identity $Instance.Number -Body $Body
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Set-CsOdcUserModern

function Set-CsOdcUserModern {
    [CmdletBinding(PositionalBinding=$false)]
    param(
    [System.Object]
    [Parameter(ValueFromPipelineByPropertyName, ValueFromPipeline)]
    ${Identity},

    [string]
    ${TollFreeServiceNumber},

    [string]
    ${BridgeName},

    [switch]
    ${SendEmail},

    [string]
    ${ServiceNumber},

    [string]
    ${SendEmailFromAddress},

    [switch]
    ${Force},

    [switch]
    ${ResetLeaderPin},

    [Alias('DC')]
    ${DomainController},

    [string]
    ${SendEmailToAddress},

    [string]
    ${BridgeId},

    [Nullable[boolean]]
    ${AllowTollFreeDialIn},

    [string]
    ${SendEmailFromDisplayName},

    [switch]
    ${AsJob})

    process {
        if ($Identity -is [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.IConferencingUser]){
            $null = $PSBoundParameters.Remove('Identity')
            $PSBoundParameters.Add('Identity', $Identity.Identity)
        }

        # Change from AllowTollFreeDialIn boolean to switch.
        if ($PSBoundParameters.ContainsKey("AllowTollFreeDialIn")){
            $null = $PSBoundParameters.Remove("AllowTollFreeDialIn")
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcUser -AllowTollFreeDialIn:$AllowTollFreeDialIn @PSBoundParameters
        }
        else{
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOdcUser @PSBoundParameters
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Provide option to Accept or Reject Disclaimer

class ProcessedSetOnlineEnhancedEmergencyServiceDisclaimerResponse {
    [string]$Country
    [string]$Version
    [string]$Content
    [string]$Response
    [string]$RespondedByObjectId
    [DateTime]$ResponseTimestamp
    [string]$CorrelationId
    [string]$Locale
}

function Set-CsOnlineEnhancedEmergencyServiceDisclaimerModern {
    [CmdletBinding(PositionalBinding=$false)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # CountryOrRegion of the Emergency Disclaimer
        ${CountryOrRegion},
        [Parameter(Mandatory=$false, position=1)]
        [System.String]
        # Version of the Emergency Disclaimer
        ${Version},
        [Parameter(Mandatory=$false)]
        [System.Management.Automation.SwitchParameter]
        # ForceAccept Emergency Disclaimer, Disclaimer will pop up without this parameter provided
        ${ForceAccept},
        [Parameter(Mandatory=$false)]
        [System.String]
        # Response of the Emergency Disclaimer
        ${Response},
        [Parameter(Mandatory=$false)]
        [System.String]
        # RespondedByObjectId of the Emergency Disclaimer
        ${RespondedByObjectId},
        [Parameter(Mandatory=$false)]
        [System.String]
        # ResponseTimestamp of the Emergency Disclaimer
        ${ResponseTimestamp},
        [Parameter(Mandatory=$false)]
        [System.String]
        # Locale of the Emergency Disclaimer
        ${Locale}
    )

    process {

        $ged = $null
        $edContent = $null
        $edCountry = $null
        $edVersion = $null
        $edResponse = $null
        $edRespondedByObjectId = $null
        $edResponseTimestamp = $null
        $edLocale = $null

        try
        {
            $ged = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsOnlineEnhancedEmergencyServiceDisclaimer @PSBoundParameters -ErrorAction Stop
            $edContent = Out-String -InputObject $ged.Content
            $edCountry = Out-String -InputObject $ged.Country
            $edVersion = Out-String -InputObject $ged.Version
            $edResponse = Out-String -InputObject $ged.Response
            $edRespondedByObjectId = Out-String -InputObject $ged.RespondedByObjectId
            $edResponseTimestamp = [DateTime]::UtcNow.ToString('u')
            $edLocale = Out-String -InputObject $ged.Locale

            if ([string]::IsNullOrEmpty($edContent))
            {
                $DiagnosticCode = Out-String -InputObject $ged.DiagnosticCode
                $DiagnosticCorrelationId = Out-String -InputObject $ged.DiagnosticCorrelationId
                #$DiagnosticDebugContent = Out-String -InputObject $ged.DiagnosticDebugContent
                $DiagnosticGenevaLogsUrl = Out-String -InputObject $ged.DiagnosticGenevaLogsUrl
                $DiagnosticReason = Out-String -InputObject $ged.DiagnosticReason
                $DiagnosticSubCode = Out-String -InputObject $ged.DiagnosticSubCode
                
                Write-Host "DiagnosticCode : "$DiagnosticCode
                Write-Host "DiagnosticCorrelationId :" $DiagnosticCorrelationId
                #Write-Host $DiagnosticDebugContent
                Write-Host "DiagnosticGenevaLogsUrl : " $DiagnosticGenevaLogsUrl
                Write-Host "DiagnosticReason : " $DiagnosticReason
                Write-Host "DiagnosticSubCode : "$DiagnosticSubCode
                Return
            }
        } catch {
            throw
        }
        
        if(!${ForceAccept})
        {
            $confirmation = Read-Host $edContent"`n[Y] Yes  [N] No  (default is `"N`")"
            switch($confirmation) {
                'Y' {
                    Break
                }
                Default {
                Return
                }
            }

        } else {
            $null = $PSBoundParameters.Remove('ForceAccept')
        }

        try {

            [System.String[]]$global:configscopes = @("48ac35b8-9aa8-4d74-927d-1f4a14a0b239/user_impersonation")
            
            Write-Host "Timestamp " $edResponseTimestamp

            $edResponse = 1

            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOnlineEnhancedEmergencyServiceDisclaimer -Country ${CountryOrRegion} -Version ${Version} -Content $edContent -Response $edResponse -RespondedByObjectId $edRespondedByObjectId  -ResponseTimestamp $edResponseTimestamp -Locale ${Locale}  -ErrorAction Stop
        } catch {
            throw
        }   
            
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: assign parameters' values and customize output

function Set-CsOnlineScheduleModern {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [Object]
        # The instance of the schedule which is updated.
        ${Instance},

        [Parameter(Mandatory=$false, position=1)]
        [Switch]
        ${Force}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }
        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }
        $params = @{
            Identity = ${Instance}.Id
            Name = ${Instance}.Name
            Type = ${Instance}.Type
            AssociatedConfigurationId = ${Instance}.AssociatedConfigurationId
        }
        # Get common parameters
        foreach($p in $PSBoundParameters.GetEnumerator())
        {
            $params += @{$p.Key = $p.Value}
        }
        $null = $params.Remove("Instance")

        if (${Instance}.Type -eq [Microsoft.Rtc.Management.Hosted.Online.Models.ScheduleType]::Fixed) {
            $DateTimeRanges = ${Instance}.FixedSchedule.DateTimeRanges
            $dateTimeRangeStandardFormat = 'yyyy-MM-ddTHH:mm:ss';
            $fixedScheduleDateTimeRanges = @()
            foreach ($dateTimeRange in $DateTimeRanges) {
                $fixedScheduleDateTimeRanges += @{
                    Start = $dateTimeRange.Start.ToString($dateTimeRangeStandardFormat)
                    End = $dateTimeRange.End.ToString($dateTimeRangeStandardFormat)
                }
            }
            $params['FixedScheduleDateTimeRange'] = $fixedScheduleDateTimeRanges
        }

        if (${Instance}.Type -eq [Microsoft.Rtc.Management.Hosted.Online.Models.ScheduleType]::WeeklyRecurrence) {
            $MondayHours = ${Instance}.WeeklyRecurrentSchedule.MondayHours
            $TuesdayHours = ${Instance}.WeeklyRecurrentSchedule.TuesdayHours
            $WednesdayHours = ${Instance}.WeeklyRecurrentSchedule.WednesdayHours
            $ThursdayHours = ${Instance}.WeeklyRecurrentSchedule.ThursdayHours
            $FridayHours = ${Instance}.WeeklyRecurrentSchedule.FridayHours
            $SaturdayHours = ${Instance}.WeeklyRecurrentSchedule.SaturdayHours
            $SundayHours = ${Instance}.WeeklyRecurrentSchedule.SundayHours

            if ($MondayHours -ne $null -and $MondayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleMondayHour'] = @()
                foreach ($mondayHour in $MondayHours){
                    $params['WeeklyRecurrentScheduleMondayHour'] += @{
                        Start = $mondayHour.Start
                        End = $mondayHour.End
                    }
                }
            }
            if ($TuesdayHours -ne $null -and $TuesdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleTuesdayHour'] = @()
                foreach ($tuesdayHour in $TuesdayHours){
                    $params['WeeklyRecurrentScheduleTuesdayHour'] += @{
                        Start = $tuesdayHour.Start
                        End = $tuesdayHour.End
                    }
                }
            }
            if ($WednesdayHours -ne $null -and $WednesdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleWednesdayHour'] = @()
                foreach ($wednesdayHour in $WednesdayHours){
                    $params['WeeklyRecurrentScheduleWednesdayHour'] += @{
                        Start = $wednesdayHour.Start
                        End = $wednesdayHour.End
                    }
                }    
            }
            if ($ThursdayHours -ne $null -and $ThursdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleThursdayHour'] = @()
                    foreach ($thursdayHour in $ThursdayHours){
                        $params['WeeklyRecurrentScheduleThursdayHour'] += @{
                            Start = $thursdayHour.Start
                            End = $thursdayHour.End
                    }
                }
            }
            if ($FridayHours -ne $null -and $FridayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleFridayHour'] = @()
                foreach ($fridayHour in $FridayHours){
                    $params['WeeklyRecurrentScheduleFridayHour'] += @{
                        Start = $fridayHour.Start
                        End = $fridayHour.End
                    }
                }
            }
            if ($SaturdayHours -ne $null -and $SaturdayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleSaturdayHour'] = @()
                foreach ($saturdayHour in $SaturdayHours){
                    $params['WeeklyRecurrentScheduleSaturdayHour'] += @{
                        Start = $saturdayHour.Start
                        End = $saturdayHour.End
                    }
                }
            }
            if ($SundayHours -ne $null -and $SundayHours.Length -gt 0) {
                $params['WeeklyRecurrentScheduleSundayHour'] = @()
                foreach ($sundayHour in $SundayHours){
                    $params['WeeklyRecurrentScheduleSundayHour'] += @{
                        Start = $sundayHour.Start
                        End = $sundayHour.End
                    }
                }
            }

            $params['WeeklyRecurrentScheduleIsComplemented'] = ${Instance}.WeeklyRecurrentSchedule.ComplementEnabled
            
            if (${Instance}.WeeklyRecurrentSchedule.RecurrenceRange -ne $null) {
                if (${Instance}.WeeklyRecurrentSchedule.RecurrenceRange.Start -ne $null) { $params['RecurrenceRangeStart'] = ${Instance}.WeeklyRecurrentSchedule.RecurrenceRange.Start }
                if (${Instance}.WeeklyRecurrentSchedule.RecurrenceRange.End -ne $null) { $params['RecurrenceRangeEnd'] = ${Instance}.WeeklyRecurrentSchedule.RecurrenceRange.End }
                if (${Instance}.WeeklyRecurrentSchedule.RecurrenceRange.Type -ne $null) { $params['RecurrenceRangeType'] = ${Instance}.WeeklyRecurrentSchedule.RecurrenceRange.Type }
            }
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOnlineSchedule @params

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($result.Diagnostic)

        $schedule = [Microsoft.Rtc.Management.Hosted.Online.Models.Schedule]::new()
        $schedule.ParseFrom($result)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: map parameters to request body

function Set-CsOnlineSipDomainModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # Domain Name parameter.
        ${Domain},

        [Parameter(Mandatory=$true, Position=1)]
        [System.String]
        # Action decides enable or disable sip domain
        ${Action}
    )

    process {

        $Body = [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.TenantSipDomainRequest]::new()

        $Body.DomainName = $Domain
        $Body.Action = $Action

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOnlineSipDomain -Body $Body
        Write-AdminServiceDiagnostic($result.Diagnostic)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Print error message in case of error

function Set-CsOnlineVoicemailUserSettingsModern {
    [CmdletBinding(PositionalBinding=$true, SupportsShouldProcess, ConfirmImpact='Medium')]
    param(
    [Parameter(Position=0, Mandatory)]
    [System.String]
    ${Identity},

    [Parameter()]
    [System.String]
    ${CallAnswerRule},

    [Parameter()]
    [System.String]
    ${DefaultGreetingPromptOverwrite},

    [Parameter()]
    [System.String]
    ${DefaultOofGreetingPromptOverwrite},

    [Parameter()]
    [System.Nullable[System.Boolean]]
    ${OofGreetingEnabled},

    [Parameter()]
    [System.Nullable[System.Boolean]]
    ${OofGreetingFollowAutomaticRepliesEnabled},

    [Parameter()]
    [System.Nullable[System.Boolean]]
    ${OofGreetingFollowCalendarEnabled},

    [Parameter()]
    [System.String]
    ${PromptLanguage},

    [Parameter()]
    [System.Nullable[System.Boolean]]
    ${ShareData},

    [Parameter()]
    [System.String]
    ${TransferTarget},

    [Parameter()]
    [System.Nullable[System.Boolean]]
    ${VoicemailEnabled},

    [Parameter(Mandatory=$false)]
    [Switch]
    ${Force}

    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        if ($PSBoundParameters.ContainsKey("Force")) {
            $PSBoundParameters.Remove("Force") | Out-Null
        }

        $result = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsOnlineVMUserSetting @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($result -eq $null) {
            return $null
        }

        $result
    }
}
function Set-CsOnlineVoiceUserV2 {
[CmdletBinding(DefaultParameterSetName='Id', SupportsShouldProcess)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        ${Identity},

        [Parameter(Mandatory=$false)]
        [System.String][AllowNull()]
        ${TelephoneNumber},

        [Parameter(Mandatory=$false)]
        [System.String][AllowNull()]
        ${LocationId}
    )
    process {
        try {
            $Body = @{
                TelephoneNumber=$TelephoneNumber
                LocationId=$LocationId
            }
            $Payload = @{
                UserId = $Identity
                Body = $Body
            }
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsUserGenerated @Payload
        }
        catch
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Set-CsPhoneNumberAssignment {
    [CmdletBinding(DefaultParameterSetName="Assignment")]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='Assignment')]
        [Parameter(Mandatory=$true, ParameterSetName='Attribute')]
        [System.String]
        ${Identity},
        
        [Parameter(Mandatory=$true, ParameterSetName='Assignment')]
        [System.String]
        ${PhoneNumber},
        
        [Parameter(Mandatory=$true, ParameterSetName='Assignment')]
        [System.String]
        ${PhoneNumberType},
        
        [Parameter(Mandatory=$false, ParameterSetName='Assignment')]
        [System.String]
        ${LocationId},
        
        [Parameter(Mandatory=$true, ParameterSetName='Attribute')]
        [System.Boolean]
        ${EnterpriseVoiceEnabled}
    )

    process {
        Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsPhoneNumberAssignment @PSBoundParameters
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Set-CsUserCallingDelegate {
    [CmdletBinding(DefaultParameterSetName="Identity")]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Identity},
        
	    [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Delegate},
        
        [Parameter(Mandatory=$false, ParameterSetName='Identity')]
        [System.Boolean]
        ${MakeCalls},
        
        [Parameter(Mandatory=$false, ParameterSetName='Identity')]
        [System.Boolean]     
        ${ManageSettings},
        
        [Parameter(Mandatory=$false, ParameterSetName='Identity')]
        [System.Boolean]
        ${ReceiveCalls}
    )

    process {

           Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsUserCallingDelegate @PSBoundParameters
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

function Set-CsUserCallingSettings {
    [CmdletBinding(DefaultParameterSetName="Identity")]
    param(
        [Parameter(Mandatory=$true, ParameterSetName='Forwarding')]
	    [Parameter(Mandatory=$true, ParameterSetName='ForwardingOnOff')]
        [Parameter(Mandatory=$true, ParameterSetName='Unanswered')]
	    [Parameter(Mandatory=$true, ParameterSetName='UnansweredOnOff')]
        [Parameter(Mandatory=$true, ParameterSetName='CallGroup')]
        [Parameter(Mandatory=$true, ParameterSetName='CallGroupMembership')]
	    [Parameter(Mandatory=$true, ParameterSetName='CallGroupNotification')]
        [Parameter(Mandatory=$true, ParameterSetName='Identity')]
        [System.String]
        ${Identity},
        
        [Parameter(Mandatory=$true, ParameterSetName='Forwarding')]
	    [Parameter(Mandatory=$true, ParameterSetName='ForwardingOnOff')]
        [System.Boolean]
        ${IsForwardingEnabled},
        
        [Parameter(Mandatory=$true, ParameterSetName='Forwarding')]
	    [ValidateSet('Immediate','Simultaneous')]
        [System.String]
        ${ForwardingType},
        
        [Parameter(Mandatory=$false, ParameterSetName='Forwarding')]
        [System.String]     
        [AllowNull()]
        ${ForwardingTarget},
        
        [Parameter(Mandatory=$true, ParameterSetName='Forwarding')]
	    [ValidateSet('SingleTarget','Voicemail','MyDelegates','Group')]
        [System.String]
        ${ForwardingTargetType},
		
        [Parameter(Mandatory=$true, ParameterSetName='Unanswered')]
	    [Parameter(Mandatory=$true, ParameterSetName='UnansweredOnOff')]
        [System.Boolean]
        ${IsUnansweredEnabled},
        
        [Parameter(Mandatory=$false, ParameterSetName='Unanswered')]
        [System.String]    
        [AllowNull()]
        ${UnansweredTarget},
        
        [Parameter(Mandatory=$false, ParameterSetName='Unanswered')]
	    [ValidateSet("", "SingleTarget","Voicemail","MyDelegates","Group")]
        [System.String]
        ${UnansweredTargetType},
		
        [Parameter(Mandatory=$true, ParameterSetName='Unanswered')]	    
        [System.String]    
        [AllowNull()]
        ${UnansweredDelay},
		
        [Parameter(Mandatory=$true, ParameterSetName='CallGroup')]
		[ValidateSet('Simultaneous','InOrder')]
        [System.String]
        ${CallGroupOrder},
        
        [Parameter(Mandatory=$true, ParameterSetName='CallGroup')]
        [System.Array]
        [AllowNull()]
        [AllowEmptyCollection()]
        ${CallGroupTargets},
        
        [Parameter(Mandatory=$true, ParameterSetName='CallGroupMembership')]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ICallGroupMembershipDetails[]]
        [AllowEmptyCollection()]
        ${GroupMembershipDetails},
		
        [Parameter(Mandatory=$true, ParameterSetName='CallGroupNotification')]
	    [ValidateSet('Ring','Mute','Banner')]
        [System.String]
        ${GroupNotificationOverride}
    )

    process {
            if ($PSBoundParameters.ContainsKey('UnansweredDelay'))
              {
                if(($UnansweredDelay -as  [TimeSpan]) -and ($UnansweredDelay -le (New-TimeSpan -Hours 0 -Minutes 1 -Seconds 0)) -and ($UnansweredDelay -ge (New-TimeSpan -Hours 0 -Minutes 0 -Seconds 0)))            
                {
                    $UnansweredDelay = $UnansweredDelay
                }
                else
                {
                    write-warning "Unanswered delay is not in correct time range"
                    return
                }
            }

           Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsUserCallingSettings @PSBoundParameters
    }
}
function Set-CsUserModern {
[CmdletBinding(DefaultParameterSetName='Id')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        ${Identity},

        [Parameter(Mandatory=$false)]
        ${EnterpriseVoiceEnabled},
 
        [Parameter(Mandatory=$false)]
        ${HostedVoiceMail},

        [Parameter(Mandatory=$false)]
        [System.String][AllowNull()]
        ${LineURI},

        [Parameter(Mandatory=$false)]
        [System.String][AllowNull()]
        ${OnPremLineURI}
    ) 

    process {

        try {
            $PhoneNumber = $LineURI
            if ($PSBoundParameters.ContainsKey('OnPremLineURI')) {
                Write-Warning -Message "OnPremLineURI will be deprecated. Please use LineURI to update user's phone number."
                if (!$PSBoundParameters.ContainsKey('LineURI')){
                    $PhoneNumber = $OnPremLineURI
                }
                else{
                    Write-Error "Please specify either one parameter OnPremLineURI or LineURI to assign phone number."
                    return
                }
            }

            $Body = @{
                EnterpriseVoiceEnabled=$EnterpriseVoiceEnabled
                HostedVoiceMail=$HostedVoiceMail
            }

            if ($PSBoundParameters.ContainsKey('LineURI') -or $PSBoundParameters.ContainsKey('OnPremLineURI')) {
                $Body.LineUri = $PhoneNumber
            }

            $Payload = @{
                UserId = $Identity
                Body = $Body
            }
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Set-CsUserGenerated @Payload
        }
        catch
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of Unregister-CsOdcServiceNumber

function Unregister-CsOdcServiceNumber {
    [CmdletBinding(PositionalBinding=$false, DefaultParameterSetName="ById")]
    param(

    [string]
    [ValidateNotNullOrEmpty()]
    [Parameter(Mandatory=$true, ParameterSetName="ById", Position=0)]
    ${Identity},

    [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ConferencingServiceNumber]
    [ValidateNotNull()]
    [Parameter(Mandatory=$true, ValueFromPipeline=$true, ParameterSetName="ByInstance")]
    ${Instance},

    [string]
    [ValidateNotNull()]
    ${BridgeId},

    [string]
    [ValidateNotNullOrEmpty()]
    ${BridgeName},

    [Alias('DC')]
    ${DomainController},

    [switch]
    ${Force},

    [switch]
    ${RemoveDefaultServiceNumber})

    process {
        if ($Identity -ne "") 
        {
            $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Unregister-CsOdcServiceNumber @PSBoundParameters
        }
        elseif ($Instance -ne $null)
        {
            $Body = [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.ConferencingServiceNumber]::new()
            $Body.Number = $Instance.Number
            $Body.PrimaryLanguage = $Instance.PrimaryLanguage
            $Body.SecondaryLanguages = $Instance.SecondaryLanguages

            if($PSBoundParameters.ContainsKey('RemoveDefaultServiceNumber') -eq $false)
            {
                $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Unregister-CsOdcServiceNumber -Body $Body -BridgeId $BridgeId -BridgeName $BridgeName
            }
            else
            {
                $output = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Unregister-CsOdcServiceNumber -Body $Body -BridgeId $BridgeId -BridgeName $BridgeName -RemoveDefaultServiceNumber
            }
        }

        $output
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Format output of the cmdlet

function Update-CsAutoAttendantModern {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$true, position=0)]
        [System.String]
        # The identity for the AA to be updated.
        ${Identity}
    )

    process {
        # Default ErrorAction to $ErrorActionPreference
        if (!$PSBoundParameters.ContainsKey("ErrorAction")) {
            $PSBoundParameters.Add("ErrorAction", $ErrorActionPreference)
        }

        $internalOutput = Microsoft.Teams.ConfigAPI.Cmdlets.internal\Update-CsAutoAttendant @PSBoundParameters

        # Stop execution if internal cmdlet is failing
        if ($internalOutput -eq $null) {
            return $null
        }

        Write-AdminServiceDiagnostic($internalOutput.Diagnostic)
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Transfer $PolisyList from user's input from string[] to object[], enable inline input

function Update-CsCustomPolicyPackage {
    [OutputType([System.String])]
    [CmdletBinding(DefaultParameterSetName='RequiredPolicyList',
               PositionalBinding=$false,
               SupportsShouldProcess,
               ConfirmImpact='Medium')]
    param(
        [Parameter(Mandatory=$true, position=0)]
        $Identity,

        [Parameter(Mandatory=$true, position=1)]
        [System.String[]]
        $PolicyList,

        [Parameter(position=2)]
        $Description
    )

    process {
        try {
            $Delimiters = ",", ".", ":", ";", " ", "`t"
            [psobject[]]$InternalPolicyList = @()
            foreach ($PolicyTypeAndName in $PolicyList)
            {
                $PolicyTypeAndNameArray = $PolicyTypeAndName -Split {$Delimiters -contains $_}, 2
                $PolicyTypeAndNameArray = $PolicyTypeAndNameArray.Trim()
                if ($PolicyTypeAndNameArray.Count -lt 2)
                {
                    throw "Invalid Policy Type and Name pair: $PolicyTypeAndName. Please use a proper delimeter"
                }
                $PolicyTypeAndNameObject = [psobject]@{
                    PolicyType = $PolicyTypeAndNameArray[0]
                    PolicyName = $PolicyTypeAndNameArray[1]
                }
                $InternalPolicyList += $PolicyTypeAndNameObject
            }
            $null = $PSBoundParameters.Remove("PolicyList")
            $null = $PSBoundParameters.Add("PolicyList", $InternalPolicyList)
            Microsoft.Teams.ConfigAPI.Cmdlets.internal\Update-CsCustomPolicyPackage @PSBoundParameters
        }
        catch
        {
            throw
        }
    }
}
# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Provide common functions for voice app team cmdlets

function Write-AdminServiceDiagnostic {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [Microsoft.Teams.ConfigAPI.Cmdlets.Generated.Models.IDiagnosticRecord[]]
        # The diagnostic object
        ${Diagnostics}
    )
    process {
        if ($Diagnostics -eq $null)
        {
            return
        }

        foreach($diagnostic in $Diagnostics)
        {
            if ($diagnostic.Level -eq $null)
            {
                Write-Output $diagnostic.Message
            }
            else
            {
                switch($diagnostic.Level)
                {
                    "Warning" { Write-Warning $diagnostic.Message }
                    "Info" { Write-Output $diagnostic.Message }
                    "Verbose" { Write-Verbose $diagnostic.Message }
                    default { Write-Output $diagnostic.Message }
                }
            }
        }
    }
}

function Get-StatusRecordStatusString {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [Int]
        # The int status from status record
        ${StatusRecordStatus}
    )
    process {
        if ($StatusRecordStatus -eq $null)
        {
            return
        }

        $status = ''

        switch ($StatusRecordStatus)
        {
            0 {$status = 'Error'}
            1 {$status = 'Pending'}
            2 {$status = 'Unknown'}
            3 {$status = 'Success'}
        }

        $status
    }
}

function Get-StatusRecordStatusCodeString {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [Int]
        # The int status from status record
        ${StatusRecordErrorCode}
    )
    process {
        if ($StatusRecordErrorCode -eq $null)
        {
            return
        }

        $statusCode = ''

        switch ($StatusRecordErrorCode)
        {
            'ApplicationInstanceAssociationProvider_AppEndpointNotFound' {$statusCode = 'AppEndpointNotFound'}
            'ApplicationInstanceAssociationStatusProvider_AppEndpointNotFound' {$statusCode = 'AppEndpointNotFound'}
            'ApplicationInstanceAssociationStatusProvider_AcsAssociationNotFound' {$statusCode = 'AcsAssociationNotFound'}
            'ApplicationInstanceAssociationStatusProvider_ApsAssociationNotFound' {$statusCode = 'ApsAppEndpointNotFound'}
            'AudioFile_FileNameNullOrWhitespace' {$statusCode = 'AudioFileNameNullOrWhitespace'}
            'AudioFile_FileNameTooShort' {$statusCode = 'AudioFileNameTooShort'}
            'AudioFile_FileNameTooLong' {$statusCode = 'AudioFileNameTooLong'}
            'AudioFile_InvalidAudioFileExtension' {$statusCode = 'InvalidAudioFileExtension'}
            'AudioFile_InvalidFileName' {$statusCode = 'InvalidAudioFileName'}
            'AudioFile_UnsupportedAudioFileExtension' {$statusCode = 'UnsupportedAudioFileExtension'}
            'CreateApplicationEndpoint_ApsAppEndpointInvalid' {$statusCode = 'ApsAppEndpointInvalid'}
            'CreateApplicationInstanceAssociation_AppEndpointAlreadyAssociated' {$statusCode = 'AcsAssociationAlreadyExists'}
            'CreateApplicationInstanceAssociation_AppEndpointNotFound' {$statusCode = 'AppEndpointNotFound'}
            'CreateApplicationInstanceAssociation_AppEndpointMissingProvisioning' {$statusCode = 'AppEndpointMissingProvisioning'}
            'DateTimeRange_InvalidDateTimeRangeBound' {$statusCode = 'InvalidDateTimeRangeFormat'}
            'DateTimeRange_InvalidDateTimeRangeKind' {$statusCode = 'InvalidDateTimeRangeKind'}
            'DateTimeRange_NonPositiveDateTimeRange' {$statusCode = 'InvalidDateTimeRange'}
            'DeserializeScheduleOperation_InvalidModelVersion' {$statusCode = 'InvalidSerializedModelVersion'}
            'EnvironmentContextMapper_ForestNameNullOrWhiteSpace' {$statusCode = 'ForestNameNullOrWhiteSpace'}
            'FixedSchedule_DuplicateDateTimeRangeStartBoundaries' {$statusCode = 'DuplicateDateTimeRangeStartBoundaries'}
            'FixedSchedule_InvalidDateTimeRangeBoundariesAlignment' {$statusCode = 'InvalidDateTimeRangeBoundariesAlignment'}
            'ModelId_InvalidScheduleId' {$statusCode = 'InvalidScheduleId'}
            'ModifyScheduleOperation_ScheduleConflictInExistingAutoAttendant' {$statusCode = 'ScheduleConflictInExistingAutoAttendant'}
            'RemoveApplicationInstanceAssociation_AppEndpointNotFound' {$statusCode = 'AppEndpointNotFound'}
            'RemoveApplicationInstanceAssociation_AssociationNotFound' {$statusCode = 'AcsAssociationNotFound'}
            'RemoveScheduleOperation_ScheduleInUse' {$statusCode = 'ScheduleInUse'}
            'Schedule_NameNullOrWhitespace' {$statusCode = 'ScheduleNameNullOrWhitespace'}
            'Schedule_NameTooLong' {$statusCode = 'ScheduleNameTooLong'}
            'Schedule_FixedScheduleNull' {$statusCode = 'ScheduleTypeMismatch'}
            'Schedule_FixedScheduleNonNull' {$statusCode = 'ScheduleTypeMismatch'}
            'Schedule_WeeklyRecurrentScheduleNull' {$statusCode = 'ScheduleTypeMismatch'}
            'Schedule_WeeklyRecurrentScheduleNonNull' {$statusCode = 'ScheduleTypeMismatch'}
            'ScheduleRecurrenceRange_InvalidType' {$statusCode = 'InvalidRecurrenceRangeType'}
            'ScheduleRecurrenceRange_UnsupportedType' {$statusCode = 'InvalidRecurrenceRangeType'}
            'ScheduleRecurrenceRange_NonPositiveRange' {$statusCode = 'InvalidRecurrenceRangeEndDateTime'}
            'ScheduleRecurrenceRange_EndDateTimeNull' {$statusCode = 'InvalidRecurrenceRangeEndDateTime'}
            'ScheduleRecurrenceRange_EndDateTimeNonNull' {$statusCode = 'InvalidRecurrenceRangeEndDateTime'}
            'ScheduleRecurrenceRange_NumberOfOccurrencesZero' {$statusCode = 'InvalidRecurrenceNumberOfOccurrences'}
            'ScheduleRecurrenceRange_NumberOfOccurrencesNull' {$statusCode = 'InvalidRecurrenceNumberOfOccurrences'}
            'ScheduleRecurrenceRange_NumberOfOccurrencesNonNull' {$statusCode = 'InvalidRecurrenceNumberOfOccurrences'}
            'TimeRange_InvalidTimeRange' {$statusCode = 'InvalidTimeRange'}
            'TimeRange_InvalidTimeRangeBound' {$statusCode = 'InvalidTimeRangeBound'}
            'WeeklyRecurrentSchedule_EmptySchedule' {$statusCode = 'EmptyWeeklyRecurrentSchedule'}
            'WeeklyRecurrentSchedule_InvalidTimeRangeBoundariesAlignment' {$statusCode = 'InvalidTimeRangeBoundariesAlignment'}
            'WeeklyRecurrentSchedule_OverlappingTimeRanges' {$statusCode = 'TimeRangesOverlapping'}
            'WeeklyRecurrentSchedule_TooManyTimeRangesPerDay' {$statusCode = 'TooManyTimeRangesForDay'}
            'WeeklyRecurrentSchedule_RecurrenceRangeNull' {$statusCode = 'ScheduleRecurrenceRangeNull'}
        }

        $statusCode
    }
}

# SIG # Begin signature block
# MIInoAYJKoZIhvcNAQcCoIInkTCCJ40CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAw0rtQEXheD6Bw
# Y6MPdZnff2ebwpHylBijQXFlMz8NkaCCDXMwggXxMIID2aADAgECAhMzAAACnGOS
# vXfHl/AoAAAAAAKcMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwMTI3MTkzNjA5WhcNMjMwMTI2MTkzNjA5WjByMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMRwwGgYDVQQDExNTa3lw
# ZSBTb2Z0d2FyZSBTYXJsMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA
# opioMHJvAOWyY9CKMQmVsLTXYjUcBdIepXX6RSOu2dPdWcjcnrZkFNHskajvpyZ1
# 0MGvySdhPaRSPpOVD0a2pSbD/1zkl1pQuqzdA5sy2gPPf03QAe64T7Tiu+a+bUXm
# 2xvAJkBKKI9fl06DA2sXj+1RJ1VPKbgbjBkFwRRMeTVMp88+POoyhP22e0HiRLHV
# E81IpA6R4IvRpyECU6sIbp8OPor29ZQYAimIpFCQtZ/3l+cZ7QbINuZ3SnLvBFJS
# riBU2G4d7VTh+708xxEIeSN7ka/yU9Kqnoguk5UyuX49ffGz+MZJnJ0GNfYAu4ad
# 8XDAio+dY1rMqPOAZGh/WQIDAQABo4IBcjCCAW4wEwYDVR0lBAwwCgYIKwYBBQUH
# AwMwHQYDVR0OBBYEFIYZz/4yJa3VDL7CKmVaPf3KpXJaMFAGA1UdEQRJMEekRTBD
# MSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVydG8gUmljbzEWMBQG
# A1UEBRMNMjMwMjU0KzQ2OTA3NjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzcitW2o
# ynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEGCCsG
# AQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0MAwG
# A1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAEccEbWQbA12GWyRF4ixzn20
# uUbDaYHCwIRxRjSwAKV9FZE0sIJrZAuCrCc+jbL99Hhi96H2xzESMFqPvO3jYZJ0
# yh+rFdkMTHTsArd93mJRjncABl3LGPNrYBq20sm2TrTli/gUtVGKbF9NGf50tyLA
# SahtheCZyPYy0l6g6dTyzpY0mb8wyIYT0yeejo4UU3fkFDK3DdJipT9REli8uEii
# XImqe/aZE+SMOGK788bbhvEKIpma64G1oPXWn2GEFwOQc0lnbhywBPBxPasiAJ/i
# FwSGA+X6+xlPJjZS4EBmDqlXN1++r3dCv/5UbnAkHZss5th+S5aHophKO5q7Mnbk
# 1vShedU3NUQZEFp/Sk6TqXv4JVUYay4ke1sqi/gFWiV6ymHhZwzMA5cJRXaMJn4A
# kBTdIg9rdBXMgIrSCdsGCFrZJfrdBqC0wDVG0/s48FkAl0ccz4fw78PnWrjsJInQ
# w9onAXiix9GlzqUIvarT8tsOgJ97BA9HihBw7fsn8edhA3oHCSxOe618l+0YyYRb
# akpB+hd9Xk40w1YjzwQnwcGnfQnewbbHMmLs7GbEV+LdXLwaBAyR2slPPngZb1Sa
# OYU5ZcQapL5MgzASN+J16FTatWFqHmNE5nR3VEi52pXCOD9YYrPLhIptrXPJfjMO
# qSLcbG08JwTDnLQUUMuWMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG
# 9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEy
# MDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIw
# MTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29k
# ZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKC
# AgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS
# 2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJ
# r9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSs
# bmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6
# t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKv
# kjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVf
# GCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DR
# elsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J6
# 4HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyim
# p31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu
# +HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHp
# MBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUC
# lTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0T
# AQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNV
# HR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9w
# cm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUF
# BwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAE
# gZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5t
# aWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR
# 4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9
# i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MT
# faaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/z
# Rive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkK
# xgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASoo
# PoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HN
# pZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbY
# ANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74
# v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E9
# 0Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmf
# wb1tbWrJUnMTDXpQzTGCGYMwghl/AgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTECEzMAAAKcY5K9d8eX8CgAAAAAApwwDQYJYIZIAWUDBAIBBQCg
# gaYwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwG
# CisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIGKoVlXPEyoSXV922XqKtl2mRAre
# Lp2e9NquGTZrzSxPMDoGCisGAQQBgjcCAQwxLDAqoAyACgBTAGsAeQBwAGWhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAJhRCQ+Q
# 1YnC9hsnhvuKirsWCKmAqLFO1A4MTFApv7Xrfnr3Bev/aHqHl6yaKqKwpHwCHfrl
# 8fHFJa1edPI7tq4FW/KMUzavEtaRwdPXLc8Z/mxhCY8Tm+JBJJ7TEb9eMSprR+kY
# LAp2E/g2fYAaHrzecLJUhW3Uf/7eMfiUk0ljjvJZ1J0G1Sv6ZR/aCKIbs7ZgWF+W
# yNODmhCNg4r9qKKkyaIDbCSf9/4jY+uE4uVyCoX8ViQK/89Qg5xAZEjqrJI/BPtU
# HlHDxEEyVBJv636sKXfD0ede85Xd8wHqwVsrzdrvCDKuBKrM2OndRPjPqc+5XK+Z
# xCy+oOvd4RqqXiyhghcVMIIXEQYKKwYBBAGCNwMDATGCFwEwghb9BgkqhkiG9w0B
# BwKgghbuMIIW6gIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYLKoZIhvcNAQkQAQSg
# ggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQgBBon
# C+FxRx742gW/F/K2nZF11F7LwAr0Q3YEyfopBxICBmIIraEe3hgTMjAyMjAzMDgw
# NTE1MjEuNDM0WjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0
# aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo4NkRGLTRCQkMt
# OTMzNTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCEWQw
# ggcUMIIE/KADAgECAhMzAAABjAGXYkc2dmY7AAEAAAGMMA0GCSqGSIb3DQEBCwUA
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIxMTAyODE5Mjc0NFoX
# DTIzMDEyNjE5Mjc0NFowgdIxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046ODZERi00QkJDLTkzMzUxJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3
# DQEBAQUAA4ICDwAwggIKAoICAQDTSGhMoRP5IaxrLD70EV2b65n6S8Q8Yt3mwXxe
# VPdTLhgapPzr4OvwbeTqr+VFqCLFEq+f6DYAVEv1W5moLW5O9rt1k30KGKi0ccWb
# LJBk9qVd0lMLycoituBMxcDCH+ZuGeahrGwj2MaWK9iCLkY04Tu7pNXhQ62dU/yK
# iFNR80wqFlol3OZYOOFYLsuM9ciFqb1CFGRXOuTF8kpzn0CxoYPc++JGSAegbF+l
# 1Yc89pbyKIQeNzg8OYIqW5bcn4h1Tfwf4yQo+Z6QLsa1FMtcoEK5YpdLxONlj/CQ
# 1zNY0Sj6Xknc5l0d5WKDGnMKd6yRl9wdfGsJfaG57uom9auSwVK2Rls4bshiZp9g
# xCtka6WXvY+dLWgh1B1idHn+eBy9JBvXUZDSQ0wPOIqxJ37mJ9RphsktnRcTE1Xi
# otcJLrkOP7wXKAKO02+QOIHkez0jsr3PFmxRvt8opIYRn3IDQmBNZtwA8Jg+24Ad
# UnxQppP3rukmbv6veGBx7fxVTf2yl54ceBoJLi9et6VMuJQwCXQ62TmdwpApzaQa
# e+7A/ZEJLeQQQUDGifAufynJ53Kt5lNsExAGp/WjeSPSKU4nv9/8/dzWudpg7TUY
# Mmia/ui2lvnP7WGtKgizy77p6u4koJOKF3SL/xtzrsAoXvrCla69b0GFtQxOxaTD
# DivjZwIDAQABo4IBNjCCATIwHQYDVR0OBBYEFJbOU4apgiFgiHlWnT6Iyt1Ai1Ij
# MB8GA1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBS
# oFCGTmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29m
# dCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRg
# MF4wXAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMv
# Y2VydHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0
# MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQEL
# BQADggIBANdoxUVYwgmp1uVBkrqiSztx0JTB48CaYQh52zK6yBQwhCVCpqN8I/2I
# bnzI4VJHHaTn2PaEAFJkHEWZuRWPCFgQLXIk9Cb3jriBTPkb645bnWLy5554HeHa
# L4OahY0o1K6Ug3J9IaBbo8IMKJGo7eqfwphXMvOh6Z8+Kv9RXHkICBVwQMAy3FtG
# tMdcEAFfIJrppDf6O6RYHlpDMvDqqEeHPscg5T2r9D1jY2dUEo9/MiXA+NvY2tAZ
# 9CddOyx8UP3w6lEerTtlTHbWDimzxXfeFJKQna4PCG2nlW0UacX4DHMUGUK9zfcs
# 9OZexzOXLr7JCABHCY0d40DbrZaosskzzgjPw5LVV8TU3rJgKQuODzX7MZeyO8wa
# aMGWLLFnBdYZYmayi8HpPqHUat+a8wq504T3YPrtJHfNPcN0DknAv1MDNfxSGLRo
# Zi2fm41QMVvEijMhEyktWk/9g4ueD6va/yzyXJa/Rp+PBlgcEnrgxZU3Edxo22PO
# Ri1CN1nluHKRrp1f4O1AP1uHfOOLRKWt9UMgvERvo6PKq18aPuJZm8mtvgCohWAd
# BoPOC6LERL2J60WKQd9/qn3sLmqhtNNsrA3QAQ/erm17Ij00g5WUmXSCLkht3nwe
# J/cks7q+n7nIdeOhIv8yWEWa8a1piZDAPsrNOb24AMXgHM/+bHa/MIIHcTCCBVmg
# AwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9z
# b2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgy
# MjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ck
# eb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+
# uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4
# bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhi
# JdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD
# 4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKN
# iOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXf
# tnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8
# P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMY
# ctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9
# stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUe
# h17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQID
# AQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4E
# FgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9
# AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9w
# cy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsG
# AQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTAD
# AQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0w
# S6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYI
# KwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWlj
# Um9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38
# Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTlt
# uw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99q
# b74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQ
# JL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1
# ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP
# 9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkk
# vnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFH
# qfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g7
# 5LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr
# 4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghi
# f9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAtMwggI8AgEBMIIBAKGB2KSB
# 1TCB0jELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UE
# CxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQL
# Ex1UaGFsZXMgVFNTIEVTTjo4NkRGLTRCQkMtOTMzNTElMCMGA1UEAxMcTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUANKLyFOur9Dyi
# mnB4bK5ks0Qmr9WggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MDANBgkqhkiG9w0BAQUFAAIFAOXQ1FgwIhgPMjAyMjAzMDgwMjU4MzJaGA8yMDIy
# MDMwOTAyNTgzMlowczA5BgorBgEEAYRZCgQBMSswKTAKAgUA5dDUWAIBADAGAgEA
# AgFfMAcCAQACAhLXMAoCBQDl0iXYAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisG
# AQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQAD
# gYEAsmVHvPmmSCmcJ7e2Yng8pA2XK7tYNv5KYF3PIKjMX72XkQqFBmplx1mgGaa2
# GcFLW7M0bIln8LcR0EckDcXdytrr14HngB/PUyYABg7gbGUCC0+f+b2gJizlhubo
# qO4tL5mIR9YDC20br7hN4lZEHUisVdZUa5lTrAUrsPZVz3kxggQNMIIECQIBATCB
# kzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAYwBl2JHNnZmOwAB
# AAABjDANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJ
# EAEEMC8GCSqGSIb3DQEJBDEiBCDOCoiMhNg6ViRICL5tPcsCNh7yPCsAQr+3lXt+
# MHr5XDCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EINWti/gVKpDPBn/E5iEF
# nYHik062FyMDqHzriYgYmGmeMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTACEzMAAAGMAZdiRzZ2ZjsAAQAAAYwwIgQgNElEpcCrWIWMYVJ/56oi
# PMRMP3oiPVYK+C4FnJ2XDFcwDQYJKoZIhvcNAQELBQAEggIASpNJzw34kVC4YwIv
# iVM0r7bYuwzLhcZb8JMphJoOHEqMP71TGNf3ZDZDrUduk25pOUUw3T74bpnKshXt
# 0phxftxlLlVKk2LkaNncfsY240jDi4BalO7HvTzwnoMAtu1hho3Q6PqWJEBVJ3Kt
# 27SMgY8OQL+hvvt04h1+ynmZfdjHGDUVbfCbDATJxg4vcRFIjRJS/E4JosqnpN9A
# ApPTmLJqAHO+fodXPFZNA01OetFmupkXY4IiiO9oO4VWj/LM5T3K50BQawVwPHaT
# 4mOLGxWB9HWvkxPKQseOgVKoOUFL6Hlo0/mxwWa9loW8RBDsn5od+gRbyI/ZAxFZ
# U5Kt6xkbTgoVQEjYAqhXJvefM4CKP5NyaGq9ABlc7tey/wC4Q/w/OqotVcnB1R+b
# 7c71tEywNwzqyHO/jOnjkGeMTocv/RdvMN9ihqF3DJE5MxwcGheR0rP2IJ+ntQce
# b8gmblG+ccC7UgvOHSTP7YTQtGoXCV0tZeQJJvdSwtx//D6G0huKa2GhuqT/bkpY
# RlPBdiawLyiFXVDdDH+1k1xKIHMM9BUoOpMlwrtVmSLxhN6L8eYUO6hC9Ej98l1I
# 1KAGucBKIYMvfHneYsUxos/ltGN5aHJ4s6yTt8mgEig+qXqdSbZPPr5GTrwTjDzI
# 7v1I0npCXadtNQB04f4Ea4pGO+Q=
# SIG # End signature block
