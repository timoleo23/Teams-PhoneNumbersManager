﻿# ----------------------------------------------------------------------------------
#
# Copyright Microsoft Corporation
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ----------------------------------------------------------------------------------

# Objective of this custom file: Integrate Get-CsOnlineVoiceUser with Get-CsUser 

function Get-CsVoiceUserList {
    [CmdletBinding(PositionalBinding=$true)]
    param(
        [Parameter(Mandatory=$false, position=0)]
        [System.String]
        # Unique identifier for the user
        ${Identity},

        [Parameter(Mandatory=$false, position=1)]
        [switch]
        #To fetch location field
        ${ExpandLocation}
    )
    process {
        if (![string]::IsNullOrWhiteSpace($Identity))
        {
            if($ExpandLocation)
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -Includedefaultproperty:$false -VoiceUserQuery:$true -Select "Objectid,EnterpriseVoiceEnabled,
                DisplayName,Location,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain" | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                Location,
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
            else
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Get-CsUser -Identity $Identity -Includedefaultproperty:$false -VoiceUserQuery:$true -Select "Objectid,EnterpriseVoiceEnabled,
                DisplayName,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain" | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                @{Name = 'Location' ; Expression = {""}},
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
        }
        else
        {
            if($ExpandLocation)
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser  -Includedefaultproperty:$false -VoiceUserQuery:$true -Select "Objectid,EnterpriseVoiceEnabled,
                DisplayName,Location,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain" | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                Location,
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
            else
            {
                Microsoft.Teams.ConfigAPI.Cmdlets.internal\Search-CsUser  -Includedefaultproperty:$false -VoiceUserQuery:$true  -Select "Objectid,EnterpriseVoiceEnabled,
                DisplayName,LineUri,TenantID,UsageLocation,DataCenter,PSTNconnectivity,SipDomain" | 
                Select-Object -Property @{Name = 'Name' ; Expression = {$_.DisplayName}},
                @{Name = 'Id' ; Expression = {$_.Identity}},
                SipDomain,
                DataCenter,
                TenantID,
                @{Name = 'Number' ; Expression = {$_.LineUri}},
                @{Name = 'Location' ; Expression = {""}},
                PSTNconnectivity,
                UsageLocation,
                EnterpriseVoiceEnabled
            }
        }
    }
}

# SIG # Begin signature block
# MIInpAYJKoZIhvcNAQcCoIInlTCCJ5ECAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBq03i8kENsxAXa
# ZWuaqmmiJNT9Zaa0zDLPkrz3AoWCHaCCDXMwggXxMIID2aADAgECAhMzAAACGYwK
# n7IWKxDmAAAAAAIZMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjEwNDI5MTkxMjU1WhcNMjIwNDI4MTkxMjU1WjByMQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMRwwGgYDVQQDExNTa3lw
# ZSBTb2Z0d2FyZSBTYXJsMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA
# nxMscK0w8ebaayvQhxPtLTkomfivSX4yNLmQJGXG+1yUKU4fmdQAhZm5mSIdFAEv
# sjAwCP3vUmh2N5R5TrAN/whfjGcDDlCYonKcrmuSaXxGuyjXKlELlRmPOaobqeo1
# 1Amcz6SRbNYBtKtRiP5ip2PfAvtJp7AvH0mZfGXKehE4C+5t8XYZ3K1JU3Tdb+3Z
# z+smovI8h/ZPe+uV2ORTxxa9kBLDvueJZbzKkn/WAIX/8rq/ywHtffSTXSueUmoe
# NJ0UCyoNBr90xtnozaCVknyRG8qWzHEZlc43FPNwIW6y8k1JSuspq+SML/HP7Fjv
# 7zcTLtM1HBBX/I9KxBJSBQIDAQABo4IBcjCCAW4wEwYDVR0lBAwwCgYIKwYBBQUH
# AwMwHQYDVR0OBBYEFAZqNYGuvWVnCVhV5aJBAvx4cJdwMFAGA1UdEQRJMEekRTBD
# MSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVydG8gUmljbzEWMBQG
# A1UEBRMNMjMwMjU0KzQ2NDU2MjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzcitW2o
# ynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEGCCsG
# AQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0MAwG
# A1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBABRKE3yDcJHa8xnyFn9Z+0m8
# vQLeUGC9933o78aSOWDkvcPFPczSqvw4cUmQnHPcRwDS1mwlYs5TmCdIS6Ij++Or
# uWxfgMdPRpveO6zT8rDWBL2sqCT/k5yCO75DVhT4kE/qEe81T4OY/Ejx3lZbBE1a
# z2k5dOL/ZWqNu8FdKSDmBZEeENOYy9UIyLf6coV2KLERB2IZ3W8U3z37fPA5nRMw
# +9sWWb98Gdm8exr4UwmnU0q8Y0KvJx/xwqOPShgiDjHsWev3fzsKSYzebkfBdLbw
# DZl9880mrGr03CfEWGDWa0tJui3LRh4csIuxWHkUrFw/R2N8baMDGPEUCh7dE+qf
# nuuMJ5tRUmnMOqyqj8dLXUZa+yxxpS91qde5asle0+WfzjLQ1D+T6ElhLBQU9LNh
# 5nhbD1+kJkVHFAU2tM3MXa2tgMVWFWQP4IqcQDWMW68M90VkGUrJ+t63oRO8HwbL
# 4IZJxG0wW/527ypSQTmpLSX6mM2vIyFHsO4zCvjDq8yfnDk25bpUNJbfOpqVkkWP
# UE+4bNIQbzcWgKgPIZDOka3pxq4vI05ns3tnvWS7TKiG+7ZYr5ZBSS6pr1Wykt0U
# aXxaUZuAWwikj2gvZAXR35f5bDg+36WoJTpQKNqzsY7dyL6SxkcZI8DcEKWEfbWd
# BX8q+w5hzEWqh7TrYJ93MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG
# 9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEy
# MDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIw
# MTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29k
# ZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKC
# AgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS
# 2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJ
# r9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSs
# bmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6
# t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKv
# kjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVf
# GCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DR
# elsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J6
# 4HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyim
# p31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu
# +HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHp
# MBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUC
# lTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0T
# AQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNV
# HR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9w
# cm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUF
# BwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAE
# gZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5t
# aWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR
# 4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9
# i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MT
# faaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/z
# Rive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkK
# xgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASoo
# PoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HN
# pZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbY
# ANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74
# v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E9
# 0Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmf
# wb1tbWrJUnMTDXpQzTGCGYcwghmDAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTECEzMAAAIZjAqfshYrEOYAAAAAAhkwDQYJYIZIAWUDBAIBBQCg
# gaYwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwG
# CisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIF4GzkLoO4rQvzx2wSJW6auqpE8S
# t3a5TlGz3euMmp6TMDoGCisGAQQBgjcCAQwxLDAqoAyACgBTAGsAeQBwAGWhGoAY
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAJD9fZBD
# zTs7Rx3YrA8y4GF6DhUC2P/wU6VlcSCmLT1r9/V+sfwEpZ+EKjBN6SbqwufWhoQW
# wkrqLH68d+nOPJkytN28f2EU/+XePFySzQcXWO0n//s42baMIgzllLDPt4fA8XL1
# sHAW2LqYIQFVLv4ckto31BjEMBa9NCeei5XJcUQCLf4CSjeQQRUsuaDRC04nVb+h
# pBLmnkc90p9hOPs64FuMJjqZa04DMTm0T1kyYEuY7XJFNMCm6ocQg6KfZO/S4FD+
# c/ol01DlTeaOKOA/PLS+Nt3wTmTjkYsPQkNIN7Sso26Prlzq7bzw1hvTmGSMLXtJ
# Al3/c0hesMbA0qyhghcZMIIXFQYKKwYBBAGCNwMDATGCFwUwghcBBgkqhkiG9w0B
# BwKgghbyMIIW7gIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYLKoZIhvcNAQkQAQSg
# ggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgBZQMEAgEFAAQg36CU
# 4iwrx/owC6PZqpZYcT4ruwRi18FjKyl+J4ddiMMCBmGVXaQyWBgTMjAyMTExMzAw
# NjQ5MzYuMDA1WjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0
# aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoyQUQ0LTRCOTIt
# RkEwMTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCCEWgw
# ggcUMIIE/KADAgECAhMzAAABhnjlGYn4JEvMAAEAAAGGMA0GCSqGSIb3DQEBCwUA
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIxMTAyODE5MjczOVoX
# DTIzMDEyNjE5MjczOVowgdIxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGlt
# aXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MkFENC00QjkyLUZBMDExJTAj
# BgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3
# DQEBAQUAA4ICDwAwggIKAoICAQDAjcbZam/oHgiMB+uB8mmd0849g7Vh3z6+V+gj
# ExbeB0INP7Mhtp+DXik67S3R6RRDHrSns9p0fg6Oeo0gTWrqV0f2e2PWAh2Xgeri
# t0QdNnokV0TbgNJtWiqpH5HgjDjDcY9t9zZDeR/LIXKP4M6GYJbD8VmJNVOVPht1
# 6PIBbqv8mfh+vfEuNu+EhNq2vfpXLLOBDRjhavvcfeBRwuNi7SqIe60MNvr6n7IM
# EaYoXOc5bzBW3sP67ZUQmgTomUrQSlUtm6x1LOF5y5TAlfFva7KABleWxr98eXBb
# 1ieUGowcn6Kb0e4rlfjHz/kHl2S4ihfmVYaMUxsPYDou78+ZQHiErQIXkbVhpS0G
# swTvcMAqTKmTtISbcGUlfBj8atWhdZhQYQfJ+uQuTCzRGgQymggSB5tk0qqNHKdE
# mBHh88IqsSHASJNMBzgNcZyLgcc6brgRDWD9IMcwWogpVLGhRuQZt0o0oeGZqG4i
# sDLjB72zutkmyS95lhmIOa0C0G3+BCiPFtnW870LXVK2GSuaSRMwtB/1wPOVUQF6
# 7oqYdfZLN7qCCd7cjhzL/khQucdneszhmklzSzYqkYsdpWsRDLjH+YCfjJph+B4f
# cwQBaRWPL+pMOHpwMIX+DLPdNpAO28WcArvQuq1sS8E90Gl4Ib+GT2XSVpjPCLLI
# Zj8eowIDAQABo4IBNjCCATIwHQYDVR0OBBYEFBm2o0UD72Z0S7+HfdSEcw3rCFwu
# MB8GA1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBS
# oFCGTmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29m
# dCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRg
# MF4wXAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMv
# Y2VydHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0
# MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQEL
# BQADggIBAMPuZ6Eljd9McoLiGP7AFYHznji5omIwwgeeEr041MztWtpNjPHRT9Nw
# snqDHDW1HMzm67ySzAk2Uc2ntF52wCLC+JVBlX0AvwhtlEslPA16ELCT4FVxjaCH
# dkZmbHy5q09mtG57KGFNMPY+8VUut/CHaWIMb90Q80gdMqPv0OURw8hag4JSnunQ
# 5EzBD3mRVqJulfz2m+OE+XYWbQIE7eldcmDRvJ2lDl0MNO/+pvT5ZgX+81URT8yg
# wRCqVRZa5cQJOrHpNrIm4snq5TsrlDJORD+XbgiEaMPN/kARk6sg1jORZXI19Q6k
# jGcqxZME3aKOln9O6fmquaj280gNPSWhuCe6Vp7Xs1oQ72iIQkkfW1Dfnd2G5GL4
# DTQ9HvzWJiXMXklTUOsR8TI3HwJaARGL3QsqxiCFkEIONDcOImN9Rkuo414esl9y
# aHPn9t+bz5oBpQ+lkV4/SDQiid3pc2ThiJhtY8Wih9zQvBypIAu24gDLPp/d35Rp
# lmynjVTiEIigaPqGgMi5Tzf1uj+Zn8CARLAbEhezSBlToD7aohR7rRB0D3r3BZLO
# 5wo6KyeD0cJJksXV2pzdBRrCvQLRTjXvzgqj29yQAbdqTBi5UZyzqEz9KoSGh72M
# fB7henzUKtMHWX34Qh26QJs/STLPHRZnO156IM3mt2KJBH2YEm6WMIIHcTCCBVmg
# AwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9z
# b2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgy
# MjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ck
# eb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+
# uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4
# bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhi
# JdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD
# 4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKN
# iOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXf
# tnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8
# P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMY
# ctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9
# stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUe
# h17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQID
# AQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4E
# FgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9
# AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9w
# cy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsG
# AQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTAD
# AQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0w
# S6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYI
# KwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWlj
# Um9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38
# Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTlt
# uw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99q
# b74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQ
# JL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1
# ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP
# 9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkk
# vnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFH
# qfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g7
# 5LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr
# 4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghi
# f9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAtcwggJAAgEBMIIBAKGB2KSB
# 1TCB0jELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UE
# CxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQL
# Ex1UaGFsZXMgVFNTIEVTTjoyQUQ0LTRCOTItRkEwMTElMCMGA1UEAxMcTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAAa7YNHNaQqWO
# ZfJJfWSiscvh8yeggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MDANBgkqhkiG9w0BAQUFAAIFAOVPrdcwIhgPMjAyMTExMzAwMzUxNTFaGA8yMDIx
# MTIwMTAzNTE1MVowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA5U+t1wIBADAKAgEA
# AgIO7wIB/zAHAgEAAgI98DAKAgUA5VD/VwIBADA2BgorBgEEAYRZCgQCMSgwJjAM
# BgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEB
# BQUAA4GBAFAcEZ51JXDxXa1qsmzGxqAW6AKhhSSBNtUDXroik22UXniDNLNMvvYJ
# INbvCNXAM42NYLJnvZ9BNwIzKTJnMlfJxBryHBaRuc8+GaLWPsHgduKUojupohyr
# gQ3cKkvoSlI4VJCy5mloVjTtyQl+0PYyk5FcH+yxOGR2e/pMlXBGMYIEDTCCBAkC
# AQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAGGeOUZifgk
# S8wAAQAAAYYwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG
# 9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgF3FhHbzfwVyicFFZ3FUKYoEMFg+6BaK4
# yIHhp8dbesAwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAamYjgsiwIVMaJ
# jJ9EBHubsVraC7FU0jDXuZwCKrxCfjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQSAyMDEwAhMzAAABhnjlGYn4JEvMAAEAAAGGMCIEIMrYiciPbkKsOPX+
# FnTFxh/0BIjnlI3L73eKm+9/zh1TMA0GCSqGSIb3DQEBCwUABIICAHV/ntLEGZ1F
# YfdC3zTEJbXYKgKYWkCLRweyFc94W2aXnF4NSt76E0rZY5e4Wxz/aFfeRzPRGd+m
# +oG0dZAhJmuxA6iIyYjhI9c+FGMjmL0yiW6aqDJR1uK1/hTPBMWjws67v7XEO2vm
# C4ZK7EMMEiAgHKA0+pRsCOAZdZYfpw86cfd0HltFPe1dAOwXz+8t1ThLT8UlLBlu
# 0saUZV6Q6F+ytf02W1V8mvBoDC9MGMVnM4yTBjxmDJjSROejd9oRmHFE6iDaKK2y
# HPWQZP32OiDu5bfGHyZHjjC+X4rIx+blkXTLJhdr9yere9N8NPFL5LLF5/92oCw+
# G09rAzKdvD9si9Uov5g0d9zBN24qMM86NnEWpeFN++Uu9Du89jOQ6fOr0tLmBfzy
# adZWRByRUPLR7vBhgDuCuMUsRbOwA5RekXjLk6pYHLDGPh42DqPsWyYWK8+C69QO
# gCqw95n9MYEkcyFgCeqvDOmcAKZEImF2/TJDvA8zgUZv8VRSdEA9jnVdCuNxteqr
# EGkc+WOn3TB+Hb2gpSAbJO1msXrooBQoqnwfYGv9YoVnWhoIBWC2Ra8nPeCZczhe
# qQ0iC/wpbvzJyDYY5K8oleJ3klP3RwfMoWat7+je2ZdKBV/5X9F/Cgwe8aoohXeu
# KIywFkPjGikOdl717A+6iKZdtBzUUKoZ
# SIG # End signature block
